package hk.com.three.mobile.proxyserver.web.sessiondbmanage;

import java.util.Calendar;

public final class CacheObject {
	private String value = "";
	private Calendar expireDate = Calendar.getInstance();
	    
    public CacheObject() {
        //expireDate.add(Calendar.DATE, 1);
    	expireDate.add(Calendar.MINUTE, 30);
    }

    public void putValue(String lvalue) {
        value = lvalue;
    }
    
    public String getValue() {
        return value;
    }

    public Calendar getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(Calendar expireDate) {
		this.expireDate = expireDate;
	}

	public boolean isExpired() {
        return expireDate.before(Calendar.getInstance());
    }

}