package hk.com.three.mobile.proxyserver.dao.customer.impl;

import hk.com.three.mobile.proxyserver.common.datasource.DataSourceFactory;
import hk.com.three.mobile.proxyserver.dao.customer.interfaces.ICustomerInfoDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CustomerInfoDAOImpl implements ICustomerInfoDAO {
    private static final Log log = LogFactory.getLog(CustomerInfoDAOImpl.class);
	public boolean authenticateCustomer(String msisdn, String password)
			 {
		return true;
	}

	public String getPartyIdByMsisdn(String msisdn)  {
		String rtn = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		msisdn = msisdn.length()==8?"852"+msisdn:msisdn;
		String sql ="SELECT PARTY_ID FROM CCV04P.PARTY_MSISDNS WHERE MSISDN = ? ";
		log.info("SQL : SELECT PARTY_ID FROM CCV04P.PARTY_MSISDNS WHERE MSISDN ="+msisdn);
		try {
			conn = DataSourceFactory.getDataSource().getConnection();
			ps   = conn.prepareStatement(sql);
			ps.setString(1, msisdn);
			rs = ps.executeQuery();
			rs.next();
			rtn = rs.getString("PARTY_ID");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
				try {
					
					if(conn!=null)conn.close();
				    
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		log.info("msisdn="+msisdn+" ,its Party_Id = "+rtn);
		return rtn;
	}

}
