package hk.com.three.mobile.proxyserver.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/*import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;*/


public class PropertiesCache {
	
	//private static final Log logger = LogFactory.getLog(PropertiesCache.class);
	private static boolean allowAllMSISDN;
	private static List<String> MSISDN_LIST = new ArrayList<String>();
	static{
		
		Properties prop = CommonUtils.loadProperties("properties/msisdnlist.properties");
		String msisdnlist = prop.getProperty("MSISDN_LIST");
		if(!"ALL".equals(msisdnlist)){
			allowAllMSISDN = false;
			String[] list = msisdnlist.split(",");
			for(int i=0;i<list.length;i++){
				MSISDN_LIST.add(list[i]);
			}
		}else{
			allowAllMSISDN = true;
		}
		
	}
	
	public static boolean allowAllMSISDN(){
		return allowAllMSISDN;
	}
	
	public static boolean containsMSISDN(String msisdn){
		return MSISDN_LIST.contains(msisdn);
	}
	
	public static void doNothing(){};
	
	public static void main(String[] args) {
		doNothing();
		System.out.println("1="+allowAllMSISDN());
		System.out.println("2="+containsMSISDN("63357472"));
	}
}
