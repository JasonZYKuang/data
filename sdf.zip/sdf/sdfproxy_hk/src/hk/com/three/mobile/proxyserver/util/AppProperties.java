package hk.com.three.mobile.proxyserver.util;

import org.apache.log4j.Logger;
import java.util.*;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: sam
 * Date: Oct 15, 2003
 * Time: 11:55:38 AM
 * To change this template use Options | File Templates.
 */
public class AppProperties extends Properties {
    private static final String MAIN_FILE;
    private static final String FILE_NAME_LOOKUP;
    private static Object cLock;
    private static AppProperties cAppProperties;
    private String cPropertyFileName;
    private Vector cPropertyFilesLoaded;
    private Vector cPropertyFilesNotLoaded;
    private Properties cPropertyFiles;
    private StringBuffer sb;
    private static Logger log;

    /**
     * Initialises the file lookups
     */
    static {
        MAIN_FILE = "/properties/AppProperties.properties";
        FILE_NAME_LOOKUP = "propertyFileNamingConvention";
        cLock = new Object();
        log = Logger.getLogger("com.ericsson.roamingtarrif.util.AppProperties");
    }

    /**
     * Clear the static object, force the system to read database again
     * @throws Exception
     */
    public static boolean clearInstance() throws Exception {
        cAppProperties = null;

        return true;
    }

    /**
     * Return an instance of the AppProperties
     *
     *AppProperties singleton instance of this class
     */
    public static AppProperties getInstance() {
        if (cAppProperties == null) {
            synchronized (cLock) {
                if (cAppProperties == null) {
                    cAppProperties = new AppProperties();
                }
            }
        }

        return cAppProperties;
    }

    /**
     * Loads all the properties in each of the files specified in
     * the main property file (MAIN_FILE)
     */
    private AppProperties() {
        String file = null;
        int counter = 0;

        try {
            cPropertyFiles = new Properties();
            cPropertyFilesLoaded = new Vector();
            cPropertyFilesNotLoaded = new Vector();
            try {
                cPropertyFiles.load(getClass().getResourceAsStream(MAIN_FILE));
            } catch (Exception ex) {
                cPropertyFiles.load(ClassLoader.getSystemResourceAsStream(MAIN_FILE));
            }

            cPropertyFileName = cPropertyFiles.getProperty(FILE_NAME_LOOKUP);

            file = getPropertyFile(cPropertyFileName + counter);

            while (file != null) {
                try {
                    try {
                        load(this.getClass().getClassLoader().getResourceAsStream(file));
                        cPropertyFilesLoaded.addElement(file);
                    } catch (Exception ex) {
                        load(ClassLoader.getSystemResourceAsStream(file));
                        cPropertyFilesLoaded.addElement(file);
                    }
                } catch (NullPointerException ex) {
                    cPropertyFilesNotLoaded.addElement(file);
                    log.info("Failed to load " + file);
                }

                counter++;
                file = getPropertyFile(cPropertyFileName + counter);
            }
        } catch (NullPointerException ex) {
            log.info(ex.getMessage());
            throw new Error("CRITICAL ERROR: There was a serious problem "
                    + "attempting to load .properties for the product. "
                    + "product cannot continue, and has exited.\n\nError Message:"
                    + ex.getMessage());
        } catch (IOException ex) {
            log.info(ex.getMessage());
            throw new Error("CRITICAL ERROR: There was a serious problem "
                    + "attempting to load .properties for the product. "
                    + "product cannot continue, and has exited.\n\nError Message:"
                    + ex.getMessage());
        }

        sb = new StringBuffer();

    }

    /**
     * Returns the Property actual file name using the
     * specified lookup.
     *
     * @param lookupName logical lookup for file
     * @return String the file name with the specified lookup
     */
    private String getPropertyFile(String lookupName) {
        return cPropertyFiles.getProperty(lookupName);
    }

    /**
     * Return a list of all the Property Files listed
     * in the main file, that were loaded in successfully
     *
     * @return Enumeration a list of all files loaded successfully
     */
    public Enumeration getPropertyFilesLoaded() {
        return cPropertyFilesLoaded.elements();
    }

    /**
     * Return a list of all the Property Files listed
     * in the main file, that failed to load
     *
     * @return Enumeration a list of all file load failures
     */
    public Enumeration getPropertyFilesNotLoaded() {
        return cPropertyFilesNotLoaded.elements();
    }

    /**
     * Get the specified property for the given key
     * @param key the property key
     * @return the trimmed value for the given key
     */
    public String getProperty(String key) {
        String s = super.getProperty(key);
        if (s == null) {
            log.debug("Property " + key + " does not exist");
            log.debug("Property " + key + " does not exist");
            return "";
        }
        return (s == null) ? s : s.trim();
    }

    public String getProperty(String key, String defaultVal) {
        String s = getProperty(key);
        return (s == null) ? defaultVal : s;
    }

    public int getIntProperty(String key) {
	String s = super.getProperty(key);

        if (s == null) {
            log.debug("Property " + key + " does not exist");
            log.debug("Property " + key + " does not exist");
        }
	if (s==null)
		s = "";
	else
		s = s.trim();

	int i = 0;
	try {
		i = Integer.parseInt(s);
	} catch (Exception e) {}
		
        return i;
    } 

    public int getIntProperty(String key, int defaultVal) {
        String s = super.getProperty(key);

        if (s == null) {
            log.debug("Property " + key + " does not exist");
            log.debug("Property " + key + " does not exist");
        }

        int i = 0;
        if (s==null) {
                i = defaultVal;
        } else {
                s = s.trim();
                try {
                        i = Integer.parseInt(s);
                } catch (Exception e) {}
        }
        return i;
    }

    private String getResource(String resource, String key, Locale locale) {
        String s = null;
        try {
            ResourceBundle bundle = ResourceBundle.getBundle(resource, locale);
            s = bundle.getString(key);
            s = (s == null) ? s : s.trim();
        } catch (MissingResourceException ex) {
            log.info("Handled Exception - No resource for = " + resource + " key = " + key + " locale= " + locale);
        }
        return s;
    }


    public static void main(String args[]) {
        /*AppProperties prop = AppProperties.getInstance();

        System.out.println("Property = " + prop.getProperty("propertyFileNamingConvention"));
        String yu = prop.getProperty("Yu");
        System.out.println("test ="+yu);*/
        


    }
}
