package hk.com.three.mobile.proxyserver.util;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ConnectCacheServer {
	
	private static final Log log  =  LogFactory.getLog(ConnectCacheServer.class);
	
    public static String handleCache(String op,String key,String value){
        String rtn = "";
    	Properties properties = null;
        String cacheServerurl = null;
        
		try {
			properties = Resource.loadPropertiesFromClassPath("config.properties");
		} catch (Exception e) {
			log.error("Can not load config.properties from classpath", e);
			return rtn;
		}
        if(properties != null){
        	cacheServerurl =  properties.getProperty("Cache_Server");
        	if(cacheServerurl != null && cacheServerurl.length()>0){
        		cacheServerurl = cacheServerurl+"?op="+op+"&key="+key+"&value="+value;
        		log.info("Connect Cache Server Url : "+cacheServerurl);
        		try{
        			HttpURLConnection huc = (HttpURLConnection) new URL(cacheServerurl).openConnection(); 
        			huc.setDoOutput(true);   
        	        huc.setDoInput(true);
        	        huc.setRequestMethod("GET");   
        	        huc.setUseCaches(false);
        	        
        	        huc.connect();   
        	        log.info("connection CacheAction URL Success!");
        	        rtn = huc.getHeaderField("RtnValue") ;
        	        if("get".equals(op)){
        	        log.info("Return value : "+rtn);
        	        }
        		}catch(Exception e){
        			log.error("Connection Cache Server Fail :", e);
        		}
        	}else{
        	  log.error("Please check property [Cache_Server] in the config.properties, can not get Cache_Server value!");
        	  return rtn;
        	}
        }
        
        
    	return rtn;
    }
}
