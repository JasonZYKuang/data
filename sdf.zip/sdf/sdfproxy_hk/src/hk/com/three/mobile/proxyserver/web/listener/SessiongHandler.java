package hk.com.three.mobile.proxyserver.web.listener;

import java.util.Hashtable;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Application Lifecycle Listener implementation class SessiongHandler
 * 
 */
public class SessiongHandler implements HttpSessionAttributeListener,
		HttpSessionListener {
	private static final Log log = LogFactory.getLog(SessiongHandler.class);

	/**
	 * Default constructor.
	 */

	public SessiongHandler() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpSessionAttributeListener#attributeRemoved(HttpSessionBindingEvent)
	 */
	public void attributeRemoved(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpSessionAttributeListener#attributeReplaced(HttpSessionBindingEvent)
	 */
	public void attributeReplaced(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpSessionAttributeListener#attributeAdded(HttpSessionBindingEvent)
	 */
	public void attributeAdded(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
	 */
	public void sessionDestroyed(HttpSessionEvent arg0) {
	}

	/**
	 * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
	 */
	public void sessionCreated(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		log.info("SessiongHandler method(sessionCreated)");
		HttpSession session = arg0.getSession();

		/*
		 * Enumeration emnse = session.getAttributeNames();
		 * while(emnse.hasMoreElements()){
		 * log.info("--------"+(String)emnse.nextElement()+"----------"); }
		 * ServletContext servletcontext= session.getServletContext();
		 * Enumeration enumeration = servletcontext.getAttributeNames();
		 * while(enumeration.hasMoreElements()){
		 * log.info("+++++++=="+(String)enumeration
		 * .nextElement()+"+++++++++++++"); }
		 */

	}


}
