package hk.com.three.mobile.proxyserver.server.customer.interfaces;

public interface ICustomerInfoSV {
  /**
   * 
   * @param msisdn
   * @param password
   * @return
   * @throws Exception
   * @author chen yongxiong 
   * ͨ��msisdn password ��֤�ͻ�
   */
  public boolean authenticateCustomer(String msisdn,String password) ;
  
  /**
   * 
   * @param msisdn
   * @return
   * @throws Exception
   * @author chen yongxiong
   * ͨ��msisdn ����ӵ�ͻ���partyid
   */
  public String  getPartyIdByMsisdn(String msisdn) ;
  
  
  /**
   * 
   * @param msisdn
   * @return status
   * @throws Exception
   * @author xiaoQinghong 2014-4-8
   * 
   */
  public String getAccountStatus(String msisdn);
}
