package hk.com.three.mobile.proxyserver.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import hk.com.three.mobile.proxyserver.util.*;


public class ConnectionManager {
	private static AppProperties prop = AppProperties.getInstance();
	private static String environment = prop.getProperty("environment");
	private String connectType;
	
	private DataSource source = null;
	private InitialContext jndiContext;
	private String poolName;
	private String jndiName;
	
	private String connectionUrl;
	private String user;
	private String password;
	
	public ConnectionManager(String dbName, String connectType){
		this.connectType = connectType;
		if("JNDI".equalsIgnoreCase(connectType)){
			this.poolName = prop.getProperty(dbName+"."+environment+".pool");
			this.jndiName = prop.getProperty(dbName+"."+environment+".jndi");
			this.JNDIConnectionManager(poolName,jndiName);
		}else{
			this.connectionUrl = prop.getProperty(dbName+"."+environment+".url");
			this.user = prop.getProperty(dbName+"."+environment+".usr");
			this.password = prop.getProperty(dbName+"."+environment+".pwd");
		}
	}

	public Connection getConnection() throws SQLException {
		if("JNDI".equalsIgnoreCase(connectType)){
			return source.getConnection();
		}else{
			Connection connection=null;
			try {
				//Class.forName(driver);
				DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
				connection=DriverManager.getConnection(connectionUrl,user,password);
			/*} catch (ClassNotFoundException e) {
				e.printStackTrace();*/
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return connection;
		}
	}
	
	/**
	 * JNDI Part
	 */
	public void JNDIConnectionManager(String poolName, String jndiUrl) {

		Hashtable jndiEnv = new Hashtable();
		jndiEnv.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,"weblogic.jndi.WLInitialContextFactory");
		jndiEnv.put(javax.naming.Context.PROVIDER_URL, jndiUrl);
		// attempt to get a reference to the context
		try {
			jndiContext = new InitialContext(jndiEnv);
		} catch (NamingException ne) {
			ne.printStackTrace();
		}
		testPool(poolName);

	}

	/**
	 * Create a JNDIConnectionManager for the given poolName with the passed
	 * <code>InitialContext</code>
	 * @param poolName
	 * The pool to find the connection pool for
	 */
	public void JNDIConnectionManager(String poolName, InitialContext ctx) {
		jndiContext = ctx;
		testPool(poolName);

	}

	private void testPool(String poolName) {
		try {
			source = (DataSource) jndiContext.lookup(poolName);
			if (source == null) {
				System.out.println("JNDIConnectionManager: The pool '" + poolName
						+ "' returned null.");
			} else {
				System.out.println("JNDIConnectionManager.testPool(" + poolName
						+ ") retrieved a reference to the pool successfully.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	/**
	 * extra logging could be placed in here to track connection usage if
	 * necessary.
	 */
	public void freeConnection(Connection conn) {
		try {
			if(conn!=null)conn.close();
		} catch (Exception e) {
			e.printStackTrace(); /* don't care */
		}

	}

	public void close() {
		if (jndiContext != null) {
			try {
				jndiContext.close();
			} catch (NamingException nex) {
			}
		}

	}
	
}
