package hk.com.three.mobile.proxyserver.dao.customer.interfaces;

public interface ICustomerInfoDAO {
	
	/**
	   * 
	   * @param msisdn
	   * @param password
	   * @return
	   * @throws Exception
	   * @author chen yongxiong 
	   * ͨ��msisdn password ��֤�ͻ�
	   */	
 public boolean authenticateCustomer(String msisdn,String password) ;
 
 
 
 /**
  * 
  * @param msisdn
  * @return
  * @throws Exception
  * @author chen yongxiong
  * ͨ��msisdn ����ӵ�ͻ���partyid
  */ 
 public String  getPartyIdByMsisdn(String msisdn) ;
}
