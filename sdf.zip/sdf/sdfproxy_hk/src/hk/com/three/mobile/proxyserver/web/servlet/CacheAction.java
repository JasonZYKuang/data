package hk.com.three.mobile.proxyserver.web.servlet;

import hk.com.three.mobile.proxyserver.web.sessiondbmanage.SessionCacheManager;
import hk.com.three.mobile.proxyserver.web.sessiondbmanage.CacheObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CacheAction extends HttpServlet {
	private static final Log log  =  LogFactory.getLog(CacheAction.class);
	private static final long serialVersionUID = 1L;
       
    public CacheAction() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain; charset=utf-8");
		
	   String op = request.getParameter("op");
	   String msisdn = request.getParameter("msisdn");
	   String sessionid = request.getParameter("sessionid");
	   PrintWriter out = response.getWriter();
	   String result = "SUCCESS";
	   
	   log.info("CacheAction op="+op+",msisdn="+msisdn+",value="+sessionid);
	   if("put".equalsIgnoreCase(op)){
		   if(msisdn !=null && sessionid != null){
			   SessionCacheManager.putCache(msisdn, sessionid);
			   log.info("["+msisdn+"] Finished put cache by msisdn ["+msisdn+"]");
		   }else{
			   log.info("["+msisdn+"] No msisdn & sessionid, put cache fail.");
			   result = "FAIL";
		   }
	   }else if("clean".equalsIgnoreCase(op)){
		   log.info("["+msisdn+"] Cache Orginal Size = "+SessionCacheManager.getAllCaches().size());
		   Iterator<Entry<Object, CacheObject>> it = SessionCacheManager.getAllCaches().entrySet().iterator();
		   while(it.hasNext()){
			   Entry<Object, CacheObject> entry = it.next();
			   if(entry.getValue().isExpired())
				   SessionCacheManager.removeCache(entry.getKey());
		   }
		   log.info("["+msisdn+"] Cache Final Size = "+SessionCacheManager.getAllCaches().size());
		   log.info("["+msisdn+"] Finished clean expired cache.");
	   }else if("cleanAll".equalsIgnoreCase(op)){
		   SessionCacheManager.cleanAllCache();
		   log.info("["+msisdn+"] Finished clean all cache.");
	   }else if("remove".equalsIgnoreCase(op)){
		   if(msisdn != null){
			   SessionCacheManager.removeCache(msisdn);
		   }
		   log.info("["+msisdn+"] Finished remove cache by msisdn ["+msisdn+"]");
	   }else if("get".equalsIgnoreCase(op)){
		   if(msisdn !=null && sessionid != null){
			   if(SessionCacheManager.getCache(msisdn)==null || "".equals(SessionCacheManager.getCache(msisdn))){
				   log.info("["+msisdn+"] This server cache expired too, fail.");
				   result = "FAIL";
			   }else if(!sessionid.equals(SessionCacheManager.getCache(msisdn))){
				   log.info("["+msisdn+"] This server has get new session, fail.");
				   result = "FAIL";
			   }else{
				   log.info("["+msisdn+"] Cache existed, success.");
				   result = "SUCCESS";
			   }
		   }else{
			   log.info("["+msisdn+"] No msisdn & sessionid, get cache fail.");
			   result = "FAIL";
		   }
	   }
	   
	   	out.println(result);
		out.flush();
		out.close();
	}

}
