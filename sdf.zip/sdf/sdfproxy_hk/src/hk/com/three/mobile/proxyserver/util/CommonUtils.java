package hk.com.three.mobile.proxyserver.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

//import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class CommonUtils {
	//private static final Logger logger = Logger.getLogger(CommonUtils.class);
	
	public static Properties loadProperties(String propertiesFilePath){
		Properties properties = new Properties();
		File file = new File(propertiesFilePath);
		InputStream inStream = null;
		if(file.exists()){
			try {
				inStream = new FileInputStream(file);
				properties.load(inStream);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				properties = null;
			} catch (IOException e) {
				e.printStackTrace();
				properties = null;
			}
		} else {
			inStream = CommonUtils.class.getClassLoader().getResourceAsStream(propertiesFilePath);
			if(inStream == null){
				CommonUtils.class.getResourceAsStream(propertiesFilePath);
			}
			if(inStream == null){
				return null;
			}
			
			try {
				properties.load(inStream);
			} catch (IOException e) {
				e.printStackTrace();
				properties = null;
			}
		}
		
		return properties;
	}
	
	public static boolean initLog4j(String configFilePath) {
		Properties props = CommonUtils.loadProperties(configFilePath);
		if(props != null){
			PropertyConfigurator.configure(props);
			System.out.println("Log4j Initialized.");
			return true;
		} else {
			System.err.println("Could not read configuration file [" + configFilePath + "].");
			return false;
		}  
	}
	
	public static String[] findFilesUnderClassPath(String path) {
		String folder="";
		try {
			folder = CommonUtils.class.getClassLoader().getResource(path).getPath();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		System.out.println(folder);
		File file = new File(folder);
		if(file.exists())return file.list();
		else return null;
	}
	
	public static void main(String[] args) {
	}
}
