package hk.com.three.mobile.proxyserver.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Servlet implementation class TestServletGetHeader
 */
public class TestServletGetHeader extends HttpServlet {
	private static final Log log = LogFactory.getLog(TestServletGetHeader.class);
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestServletGetHeader() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		String msisdn = request.getHeader("X-H3G-MSISDN");
//		String partyid = request.getHeader("X-H3G-PARTY-ID");	
		String partyid = (String)request.getParameter("partyid");
		String msisdn  = (String)request.getParameter("msisdn");
		log.info("msisdn:"+msisdn+"--------------------partyid:"+partyid);
	}

}
