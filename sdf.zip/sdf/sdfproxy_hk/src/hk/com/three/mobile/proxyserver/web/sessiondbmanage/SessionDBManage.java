package hk.com.three.mobile.proxyserver.web.sessiondbmanage;

import hk.com.three.mobile.proxyserver.util.AppProperties;
import hk.com.three.mobile.proxyserver.util.Resource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import hk.com.three.mobile.proxyserver.db.*;

public class SessionDBManage {

	private static final Log log  =  LogFactory.getLog(SessionDBManage.class);
	private static AppProperties prop = AppProperties.getInstance();
	private static String environment = prop.getProperty("environment");
	private static String dbName = "qprodDB";
	private static String connectType = prop.getProperty(dbName+"."+environment+".channel", "JDBC");
	private ConnectionManager myConnectionManager;
	
	protected static DataSource CUR_DATASOURCE = null; 
	
	public SessionDBManage() {
		myConnectionManager = new ConnectionManager(dbName, connectType);
	}
	
	public boolean insertSession(String msisdn,String sessionid)  {
		Connection conn = null;
		PreparedStatement ps = null;
		int flag = 0;
		String sql ="insert into SDFPROXY_SESSION values(?,?,?)";
		log.info("insert into SDFPROXY_SESSION values(?,?,?)");
		try {
			conn = myConnectionManager.getConnection();
			ps   = conn.prepareStatement(sql);
			ps.setString(1, msisdn);
			ps.setString(2, sessionid);
			ps.setString(3, "");
			flag = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
				try {
					if(conn!=null)conn.close();
					if(ps !=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		log.info("msisdn="+msisdn+" ,session id= "+sessionid);
		return flag ==1?true:false;
	}
	
	public boolean deleteSessionBySessionId(String sessionid){
		Connection conn = null;
		PreparedStatement ps = null;
		int flag = 0;
		String sql ="delete from SDFPROXY_SESSION where sessionid=?";
		log.info("delete from SDFPROXY_SESSION where sessionid="+sessionid);
		try {
			conn = myConnectionManager.getConnection();
			ps   = conn.prepareStatement(sql);
			ps.setString(1, sessionid);
			flag = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
				try {
					if(conn!=null)conn.close();
					if(ps !=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return flag == 1?true:false;
	}
	
	public boolean deleteSessionByName(String msisdn){
		Connection conn = null;
		PreparedStatement ps = null;
		int flag = 0;
		String sql ="delete from SDFPROXY_SESSION where msisdn=?";
		log.info("delete from SDFPROXY_SESSION where msisdn="+msisdn);
		try {
			conn = myConnectionManager.getConnection();
			ps   = conn.prepareStatement(sql);
			ps.setString(1, msisdn);
			flag = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
				try {
					if(conn!=null)conn.close();
					if(ps !=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return flag == 1?true:false;
		
	}
	
	public SessionCache sessionExist(String msisdn,String sessionid){
		SessionCache cache = new SessionCache();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs =null;
		String sql ="select * from SDFPROXY_SESSION where msisdn='"+msisdn.trim()+"' and sessionid='"+sessionid.trim()+"'";
		log.info(sql);
		System.out.println(sql);
		try {
			conn = myConnectionManager.getConnection();
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				cache.setCookie(rs.getString("cookie"));
				cache.setSessionExist(true);
				log.info("have session....................");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			log.info("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			log.info("DB Query Error: "+e.toString());
		}finally{
				try {
					if(conn!=null)conn.close();
					if(rs !=null)rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		if(!cache.isSessionExist()){
			log.info("No session exist................");
		}
		return cache;
	}
	
	public boolean updateSession(String msisdn,String sessionid){
		Connection conn = null;
		PreparedStatement ps = null;
		int flag = 0;
		String sql ="update SDFPROXY_SESSION set sessionid='"+sessionid+"' where msisdn='"+msisdn+"' ";
		log.info(sql);
		try {
			conn = myConnectionManager.getConnection();
			ps   = conn.prepareStatement(sql);
			flag = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
				try {
					if(conn!=null)conn.close();
					if(ps !=null)ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return flag == 1?true:false;
	}
	
	public boolean updateCookie(String msisdn,String sessionid,String cookie){
		Connection conn = null;
		PreparedStatement ps = null;
		int flag = 0;
		String sql ="update SDFPROXY_SESSION set cookie='"+cookie+"' where msisdn='"+msisdn+"' and sessionid='"+sessionid+"' ";
		log.info(sql);
		try {
			conn = myConnectionManager.getConnection();
			ps   = conn.prepareStatement(sql);
			flag = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
				try {
					if(conn!=null)conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return flag == 1?true:false;
	}
	
	
	
	public static void main(String[] args) {
		
		SessionDBManage sessiondb = new SessionDBManage();
		String sessionid = "20517ABB8C7D333E07EB385D80C39D19";
		String sessionidSub = sessionid;
		if(sessionid.indexOf("!")>-1){
			sessionidSub = sessionid.substring(0, sessionid.indexOf("!"));
		}
		SessionCache cache =sessiondb.sessionExist("63357472",sessionidSub);
		System.out.println("seesionFlag="+cache.isSessionExist());
		String cookieID = cache.getCookie();
		System.out.println("cookie="+cookieID);
		if (cookieID !=null && cookieID.indexOf("$")>-1) {
			String[] cookies = cookieID.split("\\$");
			for(int i=0;i<cookies.length;i++){
				System.out.println(i+"="+cookies[i]);
			}
		}
		if(cookieID == null ){
			System.out.println("####");
		}
		if(cookieID != null ){
			System.out.println("nnnn");
		}
		boolean status = sessiondb.updateCookie("63357472",sessionidSub,"JSESSIONID=C52F183E55F8C7056BC19F32AB493F7A; Path=/sdfproxy_portal$");
		System.out.println("status="+status);
		
	}
	
	public class SessionCache{
		private boolean sessionExist;
		private String cookie;
		public boolean isSessionExist() {
			return sessionExist;
		}
		public void setSessionExist(boolean sessionExist) {
			this.sessionExist = sessionExist;
		}
		public String getCookie() {
			return cookie;
		}
		public void setCookie(String cookie) {
			this.cookie = cookie;
		}
	}

}
