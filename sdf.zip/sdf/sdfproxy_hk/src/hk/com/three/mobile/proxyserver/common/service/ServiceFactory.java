package hk.com.three.mobile.proxyserver.common.service;

import hk.com.three.mobile.proxyserver.common.service.impl.ServiceInvokeImpl;
import hk.com.three.mobile.proxyserver.common.service.interfaces.IServiceInvoke;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ServiceFactory {
	private static final Log log = LogFactory.getLog(ServiceFactory.class);
	private static IServiceInvoke iservice = null;
	
	public static Object getService(Class interclass) {
		
		return iservice.getService(interclass);
	}
	
	
	
	static{
		iservice = new ServiceInvokeImpl();
	}
 
}
