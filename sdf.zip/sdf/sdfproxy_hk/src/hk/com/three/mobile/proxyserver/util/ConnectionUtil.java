package hk.com.three.mobile.proxyserver.util;


import hk.com.three.mobile.proxyserver.web.sessiondbmanage.SessionCacheManager;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ConnectionUtil {
	private static final Log log  =  LogFactory.getLog(ConnectionUtil.class);
	
	public static void startSynchronizedCacheThread(HttpServletRequest req,String msisdn,String sessionid) {
		
		String localAddr = req.getLocalAddr();
		log.info("["+msisdn+"] Local Addr = "+localAddr);
		List<String> urllist = SessionCacheManager.getCacheURList();
		for(int i=0;i<urllist.size();i++){
			String ipaddr = urllist.get(i);
			log.info("["+msisdn+"] Server["+i+"]="+ipaddr);
			if(localAddr.equals(ipaddr)) continue;
			else{
				String actionurl = SessionCacheManager.getCacheAction(ipaddr);
				if(actionurl.indexOf("?")>-1)
					actionurl = actionurl + "op=put&msisdn="+msisdn + "&sessionid="+sessionid;
				else 
					actionurl = actionurl + "?op=put&msisdn="+msisdn + "&sessionid="+sessionid;
				CacheConnection cacheCon = new CacheConnection(actionurl, msisdn, sessionid);
				cacheCon.start();
			}
		}
		
	}
	
	public static boolean checkAnotherServerCache(HttpServletRequest req,String msisdn,String sessionid){
		boolean status = false;
		String localAddr = req.getLocalAddr();
		log.info("["+msisdn+"] Local Addr = "+localAddr);
		List<String> urllist = SessionCacheManager.getCacheURList();
		for(int i=0;i<urllist.size();i++){
			String ipaddr = urllist.get(i);
			log.info("["+msisdn+"] Server["+i+"]="+ipaddr);
			if(localAddr.equals(ipaddr)) continue;
			else{
				String actionurl = SessionCacheManager.getCacheAction(ipaddr);
				if(actionurl.indexOf("?")>-1)
					actionurl = actionurl + "op=get&msisdn="+msisdn + "&sessionid="+sessionid;
				else 
					actionurl = actionurl + "?op=get&msisdn="+msisdn + "&sessionid="+sessionid;
				CacheConnection cacheCon = new CacheConnection(actionurl, msisdn, sessionid);
				cacheCon.start();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				log.info("["+msisdn+"] cacheStatus ="+cacheCon.status);
				if("SUCCESS".equals(cacheCon.status)){
					status = true;
					break;
				}
			}
		}
		return status;
	}
	
	private static class CacheConnection extends Thread{
		private String url;
		private String msisdn;
		private String sessionid;
		private String status;
		
		CacheConnection(String url,String msisdn,String sessionid){
			this.url = url;
			this.msisdn = msisdn;
			this.sessionid = sessionid;
		}
		
		public void run() {
			cacheCall(url,msisdn,sessionid);
		}
		
		private void cacheCall(String url,String msisdn,String sessionid){
			HttpURLConnection huc = null;
			try {
				log.info("["+msisdn+"] Cache URL=" + url);
				HttpURLConnection.setFollowRedirects(true);
				huc = (HttpURLConnection) new URL(url).openConnection();
				huc.setInstanceFollowRedirects(false);
				huc.setDoInput(true);
				huc.setRequestMethod("GET");
				huc.setDoOutput(false);
				huc.setAllowUserInteraction(false);
				huc.connect();
				
				int responseStatusCode = huc.getResponseCode();
				log.info("["+msisdn+"] HTTP Status code : " + responseStatusCode);
				log.info("["+msisdn+"] Http Response Message: " + huc.getResponseMessage());
				if (responseStatusCode == HttpURLConnection.HTTP_OK) {
					InputStream is = huc.getInputStream();
					int data;
					//int left = is.available();
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					while ((data = is.read()) != -1) baos.write(data);
					String strContent = new String(baos.toByteArray(), "utf-8");
					baos.close();
					log.info("["+msisdn+"] Response body = "+strContent);
					this.status = strContent;
				} else {
					log.info("["+msisdn+"] Response code not 200, Synchronized cache fail.");
				}
			} catch (Exception e) {
				log.error("["+msisdn+"] Synchronized cache fail,URL="+url);
				log.error("["+msisdn+"] Synchronized cache fail :  "+e.getMessage());
				e.printStackTrace();
			}finally{
				if (huc != null) huc.disconnect();
			}
		}
	}

}
