package hk.com.three.mobile.proxyserver.common.datasource.impl;

import hk.com.three.mobile.proxyserver.common.datasource.interfaces.IDataSource;
import hk.com.three.mobile.proxyserver.util.Resource;

import java.sql.Connection;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DataSourceImpl implements IDataSource {
	private static final Log log  =  LogFactory.getLog(DataSourceImpl.class);
	protected static DataSource CUR_DATASOURCE = null; 
	
	
	
	public DataSourceImpl() throws Exception {
		Properties prefetchPoolProperties = Resource.loadPropertiesFromClassPath("config.properties", "db.pool", true);
        if(log.isInfoEnabled()){
        	log.info("DataSource Connection pool properties:"+prefetchPoolProperties+"setted!");
        }
        CUR_DATASOURCE = BasicDataSourceFactory.createDataSource(prefetchPoolProperties);
        if(log.isInfoEnabled()){
        	log.info("DataSource Connection pool create success!");
        }
        log.info("init DB connection ....");	
        //initConnection(CUR_DATASOURCE);
        log.info("init DB connnection success!");
	}



	public Connection getConnection() throws Exception {
		// TODO Auto-generated method stub
		Connection rtn = null;
	    try {
	      rtn = CUR_DATASOURCE.getConnection();
	      rtn.setAutoCommit(false);
	    }
	    catch (Exception ex) {
	      log.info("can't  get DB connection ", ex);
	      throw ex;
	    }

	    return rtn;
	}
	
	 private void initConnection(DataSource dataSource)
	    throws Exception
	  {
	    Connection conn = null;
	    try {
	      conn = dataSource.getConnection();
	      
	    }
	    catch (Exception ex)
	    {
	    	ex.printStackTrace();
	    }
	    finally {
	      if (conn != null)
	        conn.close();
	    }
	  }
	
	public static void main(String arg[]){
		try {
			DataSourceImpl ds = new DataSourceImpl();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
