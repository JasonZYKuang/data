package hk.com.three.mobile.proxyserver.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.util.Enumeration;

/**
 * Various utilities to handle URL
 */
public final class HttpUtil {


    public static byte[] composeParameters(HttpServletRequest request) throws Exception {
        /*Enumeration<?> parameterName = request.getParameterNames();

        StringBuffer formData = new StringBuffer();
        while (parameterName.hasMoreElements()) {
            String paramName = (String) parameterName.nextElement();
            String[] enumVals;

            enumVals = request.getParameterValues(paramName);

            for (int i = 0; i < enumVals.length; ++i) {
                logger.info("Parameter Name=[" + paramName + "], value[" + i + "]=[" + enumVals[i] + "]");

                if (formData.length() > 0) formData.append("&");
                formData.append(paramName);
                formData.append("=");
                formData.append(URLEncoder.encode(enumVals[i], "UTF-8"));
            }
        }

        String formString = formData.toString();
        logger.info("After reformat the request parameter=[" + formString + "]");
        byte[] byteRep = null;

        try {
            byteRep = formString.getBytes("US-ASCII");
        } catch (Exception e) {
            logger.info("Exception when formString.getBytes(\"US-ASCII\")");
            throw new Exception();
        }
        return byteRep;
        */
    	
        InputStream is = request.getInputStream();
        byte[] rtn_data = null;
        int data;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		while ((data = is.read()) != -1) baos.write(data);
        rtn_data = baos.toByteArray();
        baos.close();
        logger.info("ComposeParameters : " + new String(rtn_data));
        return rtn_data;

    }

    public static void setHeaders(HttpServletResponse response, HttpURLConnection con) {
        String value, key;
        for (int n = 0; (value = con.getHeaderField(n)) != null; ++n) {
            key = con.getHeaderFieldKey(n);
            value = con.getHeaderField(n);
            if (key != null) {
                response.addHeader(key, value);
            }
        }
    }

    /**
     * add the header name/value pair passed by SDF to the product
     * // * @param request servlet request
     * // * @param response servlet response
     */
    /*public static void setHeaders(HttpServletRequest req, HttpURLConnection con, String product_url, Product prod) {
        Enumeration headerNames = req.getHeaderNames();
        String key, val;
        String strProdName = "";
        StringTokenizer st = new StringTokenizer(product_url, "/");
        boolean addSDFHeader = true;

        if ((prod != null) && (prod.getSDFFlag() != null) && (prod.getSDFFlag().equals("N"))) addSDFHeader = false;

        st.nextToken();
        strProdName = st.nextToken();

        while (headerNames.hasMoreElements()) {
            key = (String) headerNames.nextElement();
            val = req.getHeader(key);
            if (key.equalsIgnoreCase("x-h3g-product-base")) {
                val = val + "/" + strProdName;
            } else if (key.equalsIgnoreCase("cookie")) {
                continue;
            }

            if ((!addSDFHeader) && (key.toUpperCase().indexOf("H3G") >= 0)) {
                continue;
            }
            con.setRequestProperty(key.toUpperCase(), val);
        }
    }*/
    
    public static void setHeaders(HttpServletRequest req, HttpURLConnection huc){
    	Enumeration<?> headerNames = req.getHeaderNames();
        String key, val;
        while (headerNames.hasMoreElements()) {
            key = (String) headerNames.nextElement();
            val = req.getHeader(key);
           /* if (key.equalsIgnoreCase("cookie")) {
                continue;
            }*/
            if (key.toUpperCase().indexOf("H3G") >= 0) {
                continue;
            }
            huc.setRequestProperty(key, val);
        }
    }


    public static boolean isNotStatic(String queryString) {
    	String endingWith = getEndingWith(queryString);
        if (endingWith.equalsIgnoreCase(".html") ||
                endingWith.equalsIgnoreCase(".htm") ||
                endingWith.equalsIgnoreCase(".gif") ||
                endingWith.equalsIgnoreCase(".jpg") ||
                endingWith.equalsIgnoreCase(".png") ||
                endingWith.equalsIgnoreCase(".css")) {
            logger.info("URL=[" + queryString + "], is a static page");
            return false;
        } else {
            logger.info("URL=[" + queryString + "], is not a static page");
            return true;
        }
    }
    
    private static String getEndingWith(String lURL) {
        if (lURL.indexOf("?") >= 0) lURL = lURL.substring(0, lURL.indexOf("?"));
        int extLoc = lURL.lastIndexOf(".");     // extension position
        if (extLoc == -1) return "";            // for case without extension, ie /checker/msite/adult?a=1&b=1
        else
            return lURL.substring(lURL.lastIndexOf("."));
    }
    
    private static final Log logger = LogFactory.getLog(HttpUtil.class);
}
