package hk.com.three.mobile.proxyserver.common.datasource.interfaces;

import java.sql.Connection;

public  interface IDataSource {
	public abstract  Connection getConnection()
    throws Exception;
}
