package hk.com.three.mobile.proxyserver.common.service.interfaces;

public interface IServiceInvoke {
	
	public Object getService(Class interclass) ;

}
