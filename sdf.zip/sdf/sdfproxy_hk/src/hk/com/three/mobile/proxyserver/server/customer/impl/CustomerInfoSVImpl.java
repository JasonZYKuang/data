package hk.com.three.mobile.proxyserver.server.customer.impl;

import java.util.Hashtable;
import java.util.Properties;

import hk.com.three.mobile.proxyserver.common.service.ServiceFactory;
import hk.com.three.mobile.proxyserver.dao.customer.interfaces.ICustomerInfoDAO;
import hk.com.three.mobile.proxyserver.server.customer.interfaces.ICustomerInfoSV;
import hk.com.three.mobile.proxyserver.util.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import csBeans.StageServ;

public class CustomerInfoSVImpl implements ICustomerInfoSV {

	
	private static final Log log = LogFactory.getLog(CustomerInfoSVImpl.class);

	public boolean authenticateCustomer(String msisdn, String password){
		
		boolean flag  = false;
		Properties properties =null;
		try {
			properties = Resource.loadPropertiesFromClassPath("config.properties");
		} catch (Exception e) {
			e.printStackTrace();
		}
		Hashtable hashtable = new Hashtable();
		Hashtable hashtable1 = new Hashtable();
		hashtable.put("SvcCode", "ORAG");
		hashtable.put("SvcID", msisdn);
		hashtable.put("Password", password);
		hashtable.put("EmailAddr", "111"); // virtual parameter
		StageServ stageserv = new StageServ(properties
				.getProperty("Stagerserver.ip"), Integer.parseInt(properties
				.getProperty("Stagerserver.port")), Integer.parseInt(properties
				.getProperty("Stagerserver.toServer")));
		log.info("init stageserv Sueecss!");
		stageserv.doVerifyLogin(hashtable, hashtable1);
		int code = stageserv.getReturnCode(hashtable1);
		String rtnMsg = stageserv.getReturnMsg(hashtable1);
		log.info("Return: [authenticate value:" + code + "][" + rtnMsg + "]");
		if("0".equals(code+"")){
			flag = true;
		}
		log.info("authentication  result is "+flag+" !");
		return flag;
	}

	public String getPartyIdByMsisdn(String msisdn) {
		
		String rtn = null;
		if(!StringUtils.isBlank(msisdn)){
			ICustomerInfoDAO icustomdao = (ICustomerInfoDAO)ServiceFactory.getService(ICustomerInfoDAO.class);
			rtn  = icustomdao.getPartyIdByMsisdn(msisdn);
		}
		
		return rtn;
	}
	
	// added by xiaoqinghong 2014-4-8
	public String getAccountStatus(String msisdn){
		Properties properties =null;
		try {
			properties = Resource.loadPropertiesFromClassPath("config.properties");
		} catch (Exception e) {
			e.printStackTrace();
		}
		Hashtable hashtable = new Hashtable();
		Hashtable hashtable1 = new Hashtable();
		hashtable.put("SvcCode", "ORAG");
		hashtable.put("SvcID", msisdn);
		StageServ stageserv = new StageServ(properties
				.getProperty("Stagerserver.ip"), Integer.parseInt(properties
				.getProperty("Stagerserver.port")), Integer.parseInt(properties
				.getProperty("Stagerserver.toServer")));
//		stageserv.doGetAccNum(hashtable, hashtable1);
		stageserv.doGetAccNumP(hashtable, hashtable1);
		log.info("init stageserv Sueecss!");
		
		int code = stageserv.getReturnCode(hashtable1);
		if(code != 0){
			log.info(code + "  " +stageserv.getReturnMsg(hashtable1));
		}
		if(hashtable1.get("Status") == null){
			return "";
		}
		return hashtable1.get("Status").toString();
		
	}


}
