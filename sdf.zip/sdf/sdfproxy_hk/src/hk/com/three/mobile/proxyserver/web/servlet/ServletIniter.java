package hk.com.three.mobile.proxyserver.web.servlet;

import hk.com.three.mobile.proxyserver.common.datasource.DataSourceFactory;
import hk.com.three.mobile.proxyserver.util.PropertiesCache;
import hk.com.three.mobile.proxyserver.web.sessiondbmanage.SessionCacheManager;

import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.LogManager;

/**
 * Servlet implementation class ServletIniter
 */
public class ServletIniter extends HttpServlet {
	private static final Log log = LogFactory.getLog(ServletIniter.class);		
	private static final long serialVersionUID = 1L;
       
    public ServletIniter() {
        super();
    }
    
    
    public void init() throws ServletException {
		String prefix = getServletContext().getRealPath("WEB-INF");
		String file = getInitParameter("log4j-init-file");
		if (file != null)
			PropertyConfigurator.configureAndWatch(prefix + file);
		
		//in order to init MSISDN_LIST, don't delete
		PropertiesCache.doNothing();
		
		//in order to init SessionCacheManager, don't delete
		SessionCacheManager.init();
	}

	public void destroy() {
		LogManager.resetConfiguration();
		super.destroy();
	}

    

}
