package hk.com.three.mobile.proxyserver.db;

import hk.com.three.mobile.proxyserver.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class DBTest {
	private static AppProperties prop = AppProperties.getInstance();
	private static String environment = prop.getProperty("environment");
	private static String dbName = "qprodDB";
	private static String connectType = prop.getProperty(dbName+"."+environment+".channel", "JDBC");
	ConnectionManager myConnectionManager;
	public DBTest(){
		myConnectionManager = new ConnectionManager(dbName,connectType);
	}
	
	public void Test(String sql) throws Exception {
		Connection c = null;
		String SelectDate = "";
		PreparedStatement p = null;
		ResultSetMetaData rsmd = null;
		try {
			c = myConnectionManager.getConnection();
			p = c.prepareStatement(sql);
			ResultSet rs = p.executeQuery();
			rsmd = rs.getMetaData();
			while (rs.next()) {
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					String fieldName = rsmd.getColumnName(i).toLowerCase();
					System.out.println(rs.getString(fieldName));
				}
			}
			
		} catch (SQLException ex) {
			System.out.println("Error. " + ex.toString());
			c.rollback();
		} catch (Exception ex1) {
			System.out.println("Error. " + ex1.toString());
		} finally {
			try {
				if (p != null) {
					p.close();
				}
			} catch (Exception ex) {
				System.err.println("Exception [ " + ex.toString() + " ]");
			}
			myConnectionManager.freeConnection(c);
		}

	}
	
	/*****
	 * 
	 * 
	 * 
	 */
	public List queryForList(String sql) throws SQLException {
		List results = new ArrayList();
		HashMap record = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		String fieldName = "";
		Connection c = null;
		try {
			c = myConnectionManager.getConnection();
			stmt = c.createStatement();
			rs = stmt.executeQuery(sql);
			rsmd = rs.getMetaData();
			while (rs.next()) {
				record = new HashMap();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					fieldName = rsmd.getColumnName(i).toLowerCase();
					record.put(fieldName, rs.getString(fieldName));
				}
				results.add(record);
			}
		} catch (Exception sqlex) {
			System.err.println("runSql exception [ " + sqlex.toString() + " ]");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (c != null) {
					c.close();
				}
			} catch (Exception ex) {
				System.err.println("Exception [ " + ex.toString() + " ]");
			}
		}
		return results;
	}
	
	public int executeUpdate(String sql) {
		Statement p = null;
		int Updatecount = -1;
		Connection c = null;
		try {
			c = myConnectionManager.getConnection();
			p = c.createStatement();
			Updatecount = p.executeUpdate(sql);
			c.commit();
		} catch (Exception sqlex) {
			System.err.println("runSql exception [ " + sqlex.toString() + " ]");
		} finally {
			try {
				if (p != null) {
					p.close();
				}
				if (c != null) {
					c.close();
				}
			} catch (Exception ex) {
				System.err.println("Exception [ " + ex.toString() + " ]");
			}
		}
		return Updatecount;
	}
	
	
	public static void main(String[] args) throws Exception {
		DBTest test = new DBTest();
		//String sql = "select 'hello' as result from dual";
		String sql = "select trs_code as result from moviepass_availpool where rownum<2";
		//test.Test(sql);
		List<Map> result = test.queryForList(sql);
		String code = (String)result.get(0).get("result");
		System.out.println(code);
		
		String updateSql = "insert into moviepass_usedpool values('"+code+"')";
		System.out.println(updateSql);
		int updatedResult = test.executeUpdate(updateSql);
		System.out.println("updatedResult="+updatedResult);
		
	}

}
