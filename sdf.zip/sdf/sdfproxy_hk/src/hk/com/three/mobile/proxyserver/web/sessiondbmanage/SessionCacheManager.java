package hk.com.three.mobile.proxyserver.web.sessiondbmanage;

import hk.com.three.mobile.proxyserver.util.CommonUtils;
import hk.com.three.mobile.proxyserver.web.servlet.CacheAction;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Calendar;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public final class SessionCacheManager {
	
	private static final Log log  =  LogFactory.getLog(CacheAction.class);
	private static List<String> CACHE_URL_LIST = new ArrayList<String>();
	private static HashMap<Object,CacheObject> SESSION_CACHE= new HashMap<Object,CacheObject>();
	private static HashMap<String,String> SERVER_MAP = new HashMap<String,String>();
	
	static{
		Properties prop = CommonUtils.loadProperties("properties/cache.properties");
		String cache_iplist = prop.getProperty("CACHE_IPLIST");
		if(!"".equals(cache_iplist)){
			String[] iplist = cache_iplist.split(",");
			for(int i=0;i<iplist.length;i++){
				CACHE_URL_LIST.add(iplist[i]);
				String action = prop.getProperty("SERVER_"+iplist[i]);
				if(action !=null && !"".equals(action)){
					log.info("Add CacheIP ["+iplist[i]+"]="+action);
					SERVER_MAP.put(iplist[i], action);
				}
			}
		}
	}
	
	public static void init(){}

	public static void cleanAllCache(){
		SESSION_CACHE.clear();
	}
	
	public static String getCacheAction(String ip){
		return SERVER_MAP.get(ip);
	}
	
	public static List<String> getCacheURList(){
		return CACHE_URL_LIST;
	}
	
	public static HashMap<Object,CacheObject> getAllCaches(){
		return SESSION_CACHE;
	}
	
	public static String getCache(Object key) {
        CacheObject obj = SESSION_CACHE.get(key);
        if (obj == null)
            return "";
        return obj.getValue();
    }

    public static void putCache(String key, String value) {
        if (value == null) return;
        CacheObject obj = new CacheObject();
        obj.putValue(value);
        SESSION_CACHE.put(key, obj);
    }
    
    public static void removeCache(Object key){
    	SESSION_CACHE.remove(key);
	}
    
    public static String getExpireDate(String key){
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	CacheObject obj = SESSION_CACHE.get(key);
        if (obj == null)
            return "";
        Calendar cal = obj.getExpireDate();
        return sdf.format(cal.getTime());
    }
    
    public static void setExpireDateByKey(String key, int calendarField, int second){
    	CacheObject obj = SESSION_CACHE.get(key);
        if (obj == null)
            return;
        Calendar cal = Calendar.getInstance();
        cal.add(calendarField, second);
        obj.setExpireDate(cal);
    }
    
    public static boolean isExpired(String key){
    	CacheObject obj = SESSION_CACHE.get(key);
        if (obj == null)
            return false;
        return obj.isExpired();
    }
	
	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String key = "63357472";
		init();
		SessionCacheManager.putCache(key, "AABBCC");
		System.out.println("     Value="+SessionCacheManager.getCache(key));
		
		System.out.println("ExprieDate="+SessionCacheManager.getExpireDate(key));
		System.out.println("       Now="+sdf.format(Calendar.getInstance().getTime()));
		try {    
	        Thread.sleep(1000*10);    
		} catch(InterruptedException ex) {    }
		
		System.out.println("\n---------------------------------------\n");
		
		SessionCacheManager.setExpireDateByKey(key, Calendar.SECOND, 20);
		System.out.println("ExprieDate="+SessionCacheManager.getExpireDate(key));
		System.out.println("       Now="+sdf.format(Calendar.getInstance().getTime()));
		System.out.println("isExpired?="+SessionCacheManager.isExpired(key));
		
		try {    
	        Thread.sleep(1000*30);    
		} catch(InterruptedException ex) {    } 
		
		System.out.println("\n---------------------------------------\n");
		System.out.println("ExprieDate="+SessionCacheManager.getExpireDate(key));
		System.out.println("       Now="+sdf.format(Calendar.getInstance().getTime()));
		System.out.println("isExpired?="+SessionCacheManager.isExpired(key));
		
		
	}
}
