package hk.com.three.mobile.proxyserver.common.service.impl;

import hk.com.three.mobile.proxyserver.common.service.interfaces.IServiceInvoke;
import hk.com.three.mobile.proxyserver.util.StrHepler;

public class ServiceInvokeImpl implements IServiceInvoke {

	public Object getService(Class interclass)  {
		// TODO Auto-generated method stub
		 String className = StrHepler.getImplclassnameByInterclassname(interclass);
		 Object obj =null;
		try {
			obj = newInstance(className);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return  obj;
	}
 
   public  Object newInstance(String className) throws Exception{
	   return Class.forName(className).newInstance();
   }
}

