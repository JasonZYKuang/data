package hk.com.three.mobile.proxyserver.web.servlet;

import hk.com.three.mobile.proxyserver.util.Resource;
import hk.com.three.mobile.proxyserver.web.sessiondbmanage.SessionDBManage;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LogoutAction extends HttpServlet {
	
	private static final Log log  =  LogFactory.getLog(LogoutAction.class);
	private static final long serialVersionUID = 1L;
	
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req,resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = req.getSession();
		String msisdn =(String)session.getAttribute("msisdn");
		//String proxyUrl = (String)session.getAttribute("proxyUrl");
		SessionDBManage sessiondb = new SessionDBManage();
		log.info("ready to logout..."+msisdn);
		if(msisdn!=null){
		log.info("delete the sesseion id in db");
		sessiondb.deleteSessionByName(msisdn);
		log.info("session invalidate!");
		session.invalidate();
		}
		Properties properties = null;
		try {
			properties = Resource
					.loadPropertiesFromClassPath("config.properties");
		} catch (Exception e) {
			e.printStackTrace();
		}
		String mainURL = properties.getProperty("mainURL");
//		String outURL="";
//		if(proxyUrl!=null&&proxyUrl.length()>0){
//			outURL =proxyUrl;
//		}else{
//			outURL = mainURL;
//		}
//		log.info("sendRedirect to the main page-"+proxyUrl);
		log.info("sendRedirect to the main page-"+req.getContextPath()+mainURL);
		resp.sendRedirect(req.getContextPath()+mainURL);
//		resp.sendRedirect(req.getContextPath()+outURL);
	}
	
	

}
