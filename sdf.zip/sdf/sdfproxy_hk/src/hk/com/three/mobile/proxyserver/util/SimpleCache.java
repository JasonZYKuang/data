package hk.com.three.mobile.proxyserver.util;

import java.util.HashMap;


public class SimpleCache {
	private static final HashMap cacheMap = new HashMap();
	
	
	public synchronized static void clearCache(){
		cacheMap.clear();
	}
	
	public static Object getValueByKey(String key){
		
		return cacheMap.get(key);
	}
	
	public static void putCacheKeyValue(Object key,Object value){
		cacheMap.put(key, value);
	}
	
	public static void removeCacheByKey(Object key){
		cacheMap.remove(key);
	}
	
	public static HashMap getCacheMap(){
		return cacheMap;
	}
}
