package hk.com.three.mobile.proxyserver.common.datasource;

import hk.com.three.mobile.proxyserver.common.datasource.impl.DataSourceImpl;
import hk.com.three.mobile.proxyserver.common.datasource.interfaces.IDataSource;
public class DataSourceFactory {
 private static IDataSource dataSource = null;
 
 public  static IDataSource getDataSource ()  {
	
	return dataSource;
 }
 
 static{
	 try {
		dataSource = new   DataSourceImpl();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 }
 
}
