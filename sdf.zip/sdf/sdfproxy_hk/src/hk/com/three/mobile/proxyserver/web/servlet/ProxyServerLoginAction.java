package hk.com.three.mobile.proxyserver.web.servlet;

import hk.com.three.mobile.proxyserver.common.service.ServiceFactory;
import hk.com.three.mobile.proxyserver.server.customer.interfaces.ICustomerInfoSV;
import hk.com.three.mobile.proxyserver.util.ConnectionUtil;
import hk.com.three.mobile.proxyserver.util.DecryptStrUtil;
import hk.com.three.mobile.proxyserver.util.PropertiesCache;
import hk.com.three.mobile.proxyserver.web.sessiondbmanage.SessionCacheManager;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.NDC;

public class ProxyServerLoginAction extends HttpServlet {
	private static final Log log = LogFactory
			.getLog(ProxyServerLoginAction.class);
	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {
		super.init();
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProxyServerLoginAction() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// doPost(request,response);
		HttpSession session = req.getSession();
		// get session msisdn and partyId
		/**
		 * String session_msisdn = (String)session.getAttribute("msisdn");
		 * String session_partyid = (String)session.getAttribute("partyid");
		 * if(!StringUtils.isBlank(session_msisdn) &&
		 * !StringUtils.isBlank(session_partyid)){ log.info(
		 * "*************************************************************************"
		 * ); long stime = System.currentTimeMillis();
		 * log.info("msisdn:"+session_msisdn+"  start logining ...");
		 * log.info("this user information msisdn:"
		 * +session_msisdn+"  partyId:"+session_partyid);
		 * ProxySkipUtil.proxyProcess(req, resp, session_msisdn,
		 * session_partyid,null);
		 * log.info("msisdn:"+session_msisdn+"  logined SDF consume: "
		 * +(System.currentTimeMillis()-stime)+" ms"); log.info(
		 * "*************************************************************************"
		 * ); return; }
		 */

		long startTime = System.currentTimeMillis();
		String msisdn = req.getParameter("mobileno");
		String password = req.getParameter("password");
		String queryStringUrl = (String) session.getAttribute("proxyUrl");
		log.info("proxyUrl ---" + queryStringUrl);
		if("".equals(queryStringUrl) || queryStringUrl == null || "null".equals(queryStringUrl)){
			log.info("proxyUrl set to defalt = /redir/index.jsp");
			queryStringUrl = "/redir/index.jsp";
		}
		log.info("cookie session is " + req.isRequestedSessionIdFromCookie());
		log.info("URL session   is  " + req.isRequestedSessionIdFromURL());
		//String url = null;
		resp.setCharacterEncoding("UTF-8");

		if (!StringUtils.isBlank(msisdn) && !StringUtils.isBlank(password)) {
			NDC.push(msisdn);
			log
					.info("***************************************************************");
			log.info("msisdn:" + msisdn + "  start logining ... ");
			
			boolean allowALLMSISDN = PropertiesCache.allowAllMSISDN();
			if(!allowALLMSISDN){
				boolean allowThisMSISDN = PropertiesCache.containsMSISDN(msisdn);
				if(!allowThisMSISDN){
					log.info("this msisdn not allow login !");
					req.setAttribute("result", "3");
					req.getRequestDispatcher("login.jsp").forward(req, resp);
					popNDC();
					return;
				}else{
					log.info("this msisdn allow login, continue !");
				}
			}
			
			/*** Authentication customer here
			 **/ 
			ICustomerInfoSV icussv = (ICustomerInfoSV)ServiceFactory .getService(ICustomerInfoSV.class);
			boolean flag = icussv.authenticateCustomer(msisdn, password);
			String status = icussv.getAccountStatus(msisdn);
			log.info(msisdn + "=> status=" + status);
			
			//boolean flag = true;
			//Yu Testing end
			 
			//boolean flag = true; zdy test
			log.info("authenticate msisdn and password time :"
					+ (System.currentTimeMillis() - startTime) + "ms");
			if (flag && "ACTIVE".equals(status)) {
				/** get PartyId by Msisdn*/
				//ICustomerInfoSV icussv = (ICustomerInfoSV)ServiceFactory.getService(ICustomerInfoSV.class);
				String partyid = icussv.getPartyIdByMsisdn(msisdn);
				
				/**Properties properties = null;
		        try {
		          properties = Resource.loadPropertiesFromClassPath("config.properties");
		        } catch (Exception e) {
		          e.printStackTrace();
		        }
		        String partyid = properties.getProperty(msisdn);*/
		        //Yu Testing end
				 
				log.info("get partyid time :"
						+ (System.currentTimeMillis() - startTime) + "ms");
				if (!StringUtils.isBlank(partyid)) {
					log.info("this user information msisdn:" + msisdn
							+ "  partyId:" + partyid);
					//String IP = null;
					// DecryptStrUtil dct = new DecryptStrUtil();

					String sessionid = session.getId();
					String sessionidSub = sessionid;
					if(sessionid.indexOf("!")>-1){
						sessionidSub = sessionid.substring(0, sessionid.indexOf("!"));
					}
					//add session check by zdy and add cookie
					/*SessionDBManage sessiondb = new SessionDBManage();
					log.info("chek the session id ="+session.getId());
					
					SessionCache cache =sessiondb.sessionExist(msisdn, sessionidSub);
					if(!cache.isSessionExist()){
						//delete old session and add new session
						log.info("session not exist,delete the user and insert the session and msisdn into DB");
						sessiondb.deleteSessionByName(msisdn);
						log.info("db-new login and insert session into db");
						sessiondb.insertSession(msisdn, sessionidSub);
						
					}*/

					log.info("add sessionid into cache, sessionid="+sessionidSub);
					SessionCacheManager.putCache(msisdn, sessionidSub);
					log.info("Start call another server to synchronized cache.");
					ConnectionUtil.startSynchronizedCacheThread(req, msisdn, sessionidSub);
					
					log.info("add cookie...");
					String remeberMe ="0";
					if(req.getParameter("remeberMe")!=null){
						remeberMe =req.getParameter("remeberMe");
					}
					
					DecryptStrUtil decryptStr = new DecryptStrUtil();
					Cookie cookie = new Cookie("mobileNO",msisdn);
					if("1".equals(remeberMe)){
					cookie.setMaxAge(30*24*60*60);
					}else{
						cookie.setMaxAge(0);
					}
				    cookie.setPath("/");
				    cookie.setDomain(".three.com.hk");
				    resp.addCookie(cookie);
				    cookie = new Cookie("password",decryptStr.encrypt(password));
				    if("1".equals(remeberMe)){
						cookie.setMaxAge(30*24*60*60);
						}else{
							cookie.setMaxAge(0);
						}
				    cookie.setPath("/");
				    cookie.setDomain(".three.com.hk");
					resp.addCookie(cookie);
					cookie = new Cookie("remeberMe",remeberMe);
						cookie.setMaxAge(30*24*60*60);
					    cookie.setPath("/");
					    cookie.setDomain(".three.com.hk");
					resp.addCookie(cookie);              
					log.info("end add cookie");
					
					
					//end 
					
					session.setAttribute("msisdn", msisdn);
					session.setAttribute("partyid", partyid);
					session.setMaxInactiveInterval(300);// set session 300
					// second timeout
					// add by yongxiong.chen for put msisdn=sessionID
					// maping(begin)
					/**
					 * String sessionId = session.getId();
					 * log.info("Session ID:"+sessionId); // for weblogic
					 * sessionID if(sessionId.indexOf("!") != -1){ sessionId =
					 * sessionId.substring(0, sessionId.indexOf("!")); } String
					 * cacheValue = ConnectCacheServer.handleCache("put",
					 * msisdn, sessionId);
					 * log.info("Put into cache :msisdn="+msisdn
					 * +",sessionId="+sessionId+",<"+msisdn+","+sessionId+">");
					 */
					// add by yongxiong.chen for put msisdn=sessionID
					// maping(end)
					// **set cookies*//*
					/*
					 * Cookie msisdn_cookie = new
					 * Cookie("msisdn",dct.encrypt(msisdn));
					 * msisdn_cookie.setMaxAge(60*2); Cookie partyid_cookie =
					 * new Cookie("partyid",dct.encrypt(partyid));
					 * partyid_cookie.setMaxAge(60*2);
					 * resp.addCookie(msisdn_cookie);
					 * resp.addCookie(partyid_cookie);
					 */

					// inject PartyId and Msisdn into httpheader
					/**
					 * ProxySkipUtil.proxyProcess(req, resp, msisdn, partyid,
					 * queryStringUrl); log.info("msisdn:" + msisdn +
					 * "  logined SDF consume: " + (System.currentTimeMillis() -
					 * startTime) + " ms");
					 */
					resp.sendRedirect(req.getContextPath() + queryStringUrl);
					log.info("response sendRedirect to URL : "+ req.getContextPath() + queryStringUrl);
					log.info("***************************************************************");
					popNDC();

				} else {
					log.info("can't get Party_Id !");
					req.setAttribute("result", "2");
					req.getRequestDispatcher("login.jsp").forward(req, resp);
					popNDC();
				}

			} else {
				log.info("authentication Fail or account statuts is not Active");
				req.setAttribute("result", "1");
				req.getRequestDispatcher("login.jsp").forward(req, resp);
				popNDC();
			}
		} else {
			log.info("can't get  msisdn and password from request Parameters!");
			req.getRequestDispatcher("login.jsp").forward(req, resp);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);

	}

	@Override
	public void destroy() {
		System.out.println("****** begin destroy() servlet ******");
		NDC.remove();
		super.destroy();
		System.out.println("****** end destroy() servlet ******");
	}

	public String getIpAddr(HttpServletRequest request) {
		String ip = null;
		Enumeration<?> enumer = request.getHeaderNames();
		while (enumer.hasMoreElements()) {
			String headername = (String) enumer.nextElement();

			if ("X-FORWARDED-FOR".equals(headername)) {
				ip = request.getHeader(headername);
			} else if ("client-IP".equals(headername)) {
				ip = request.getHeader(headername);
			}

			if ((ip != null) && (ip.length() != 0))
				break;
		}

		if ((ip == null) || (ip.length() == 0))
			ip = request.getRemoteAddr();

		return ip;
	}
	
	public void popNDC(){
		log.info("Start pop Log4J NDC stack.");
		try {
            while (NDC.getDepth() != 0) {
                NDC.pop();
            }
        }
        catch (Exception e) {
            log.error("Error popping message ID off of Log4J NDC stack.", e);
        }
	}

}
