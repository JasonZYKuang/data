package hk.com.three.mobile.proxyserver.web.filter;

import hk.com.three.mobile.proxyserver.util.AppProperties;
import hk.com.three.mobile.proxyserver.util.ConnectionUtil;
import hk.com.three.mobile.proxyserver.util.ProxySkipUtil;
import hk.com.three.mobile.proxyserver.util.StrHepler;
import hk.com.three.mobile.proxyserver.web.sessiondbmanage.SessionCacheManager;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.NDC;

/**
 * Servlet Filter implementation class LoginFilter
 */
public class LoginFilter implements Filter {
  private static final Log log = LogFactory.getLog(LoginFilter.class);
  private static AppProperties prop = AppProperties.getInstance();
    /**
     * Default constructor. 
     */
    public LoginFilter() {
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		System.out.println("****** begin destroy() filter ******");
		NDC.remove();
		System.out.println("****** end destroy() filter ******");
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest  req = (HttpServletRequest)request;
		HttpServletResponse respon = (HttpServletResponse)response;
		req.setCharacterEncoding("UTF-8");
		respon.setCharacterEncoding("UTF-8");
		String inComeIP = getIPAddress(req);
		log.info("IP Address ="+inComeIP);
		log.info("###########################");
		log.info("## Login Filter start..  ##");
		log.info("###########################");
		log.info("user-agent="+req.getHeader("user-agent"));
		String url = req.getRequestURI();
		log.info("["+inComeIP+"] getRequestURI()="+url);
		log.info("["+inComeIP+"] getContextPath()="+req.getContextPath());
		log.info("["+inComeIP+"] getRequestURL()="+req.getRequestURL());
		log.info("["+inComeIP+"] getQueryString()="+req.getQueryString());
		
		String iplist = prop.getProperty("IPLIST");
		if(!"ALL".equals(iplist)){
			if(iplist.indexOf(inComeIP) < 0){
				String redireUrl4NotAllow = prop.getProperty("RedirURL4NotAllow");
				if(url.indexOf("proxyerror")<0){
					log.info("["+inComeIP+"] Not Allow Login ! URL forward to "+redireUrl4NotAllow);
					req.getRequestDispatcher(redireUrl4NotAllow).forward(req, respon);
					return;
				}else{
					log.info("["+inComeIP+"] This url within proxyerror folder, no need forward.");
				}
			}
		}
			
		log.info("["+inComeIP+"] Go-ahead this action !");
		
		
		if(url.indexOf(req.getContextPath()) == -1){
			chain.doFilter(request, response);
			return;
		}
		
		if(url.equals(req.getContextPath())){
			url = url + "/redir/index.jsp";
			log.info("url is empty, set default value=" + url);
		} else if ((url).equals(req.getContextPath()+"/")){
			url = url + "redir/index.jsp";
			log.info("url is empty, set default value=" + url);
		}
		
		String filterUrl = url.substring(req.getContextPath().length()+1, url.length());
		log.info("["+inComeIP+"] *** filterurl = "+filterUrl);
		// || filterUrl.indexOf("/")<0 
		if(url.startsWith(req.getContextPath()+"/scripts")||url.startsWith(req.getContextPath()+"/proxyerror")){
			log.info("Internal call !");
			chain.doFilter(request, response);
			return;
		}
		
		if(filterUrl.indexOf("/")>-1){
			filterUrl = filterUrl.substring(0,filterUrl.indexOf("/"));
		}
		log.info("["+inComeIP+"] *** filterurl after substring ="+filterUrl);
		if(	filterUrl.endsWith(".jsp")
			||filterUrl.endsWith(".ico")
			||filterUrl.endsWith("Action")
			||filterUrl.endsWith("html")
		   ){
			log.info("Internal call !");
			chain.doFilter(request, response);
			return;
		}
		
		log.info("into filter verify!");
		long startTime =  System.currentTimeMillis();
		HttpSession session = req.getSession();
		String msisdn = (String)session.getAttribute("msisdn");
		String partyid = (String)session.getAttribute("partyid");
		String CookieID = (String)session.getAttribute("CookieID");
		
		log.info("["+inComeIP+"] ****************************************");
		log.info("["+inComeIP+"] **  SESSION:"+session.getId());
		log.info("["+inComeIP+"] **   MSISDN:"+msisdn);
		log.info("["+inComeIP+"] **  PARTYID:"+partyid);
		log.info("["+inComeIP+"] ** CookieID:"+CookieID);
		log.info("["+inComeIP+"] ****************************************");
		String queryStringUrl = StrHepler.setForwordURL(req);
		session.removeAttribute("proxyUrl");
		session.setAttribute("proxyUrl", queryStringUrl);
		

		
		/** get cookies */
		/*if (StringUtils.isBlank(msisdn) || StringUtils.isBlank(partyid)) {
			Cookie cookie[] = req.getCookies();
			if (cookie != null && cookie.length > 0) {
				for (int i = 0; i < cookie.length; i++) {
					if ("msisdn".equalsIgnoreCase(cookie[i].getName())) {
						msisdn = cookie[i].getValue();
					} else if ("partyid".equalsIgnoreCase(cookie[i].getName())) {
						partyid = cookie[i].getValue();
					}
				}
				if(!StringUtils.isBlank(msisdn) && !StringUtils.isBlank(partyid)){
					msisdn  = decrypt.decrypt(msisdn);
					partyid = decrypt.decrypt(partyid);
				}
				
			}
		}*/
		//String handsetNum = req.getParameter("mobileno");
		//String password   = req.getParameter("password"); 
		
		if(!StringUtils.isBlank(msisdn) && !StringUtils.isBlank(partyid)){
			//add by yongxiong.chen for check msisdn=sessionID maping(begin)
			 /**
			 String cacheValue = ConnectCacheServer.handleCache("get", msisdn, null);
			 log.info("Get msisdn mapping session:"+msisdn+"="+cacheValue);
			 String sessionId = session.getId();
			 log.info("Session ID:"+sessionId);
			 // for weblogic sessionID
			 if(sessionId.indexOf("!") != -1){
				 sessionId = sessionId.substring(0, sessionId.indexOf("!"));
			 }
			 if(!sessionId.equals(cacheValue)){
				 log.info("This msisdn have login on the other place. Must need to relogin!");
				 req.getRequestDispatcher("/login.jsp?JSESSIONID="+session.getId()).forward(req, respon); 
				 return;
			 }
			 */
			
			/*log.info("["+currentIP+"] session check "+session.getId());
				SessionDBManage sessiondb = new SessionDBManage();
				String sessionid = session.getId();
				String sessionidSub = sessionid;
				if(sessionid.indexOf("!")>-1){
					sessionidSub = sessionid.substring(0, sessionid.indexOf("!"));
				}
				SessionCache cache =sessiondb.sessionExist(msisdn, sessionidSub);
			if(!cache.isSessionExist()){
			log.info("["+currentIP+"] !!!!!!!!  session not exist");
				req.getRequestDispatcher("/login.jsp?JSESSIONID="+session.getId()).forward(req, respon);
				//session.invalidate();
				return;
			}*///ZuoyuRemark
			//end session handle
			
			String sessionid = session.getId();
			String sessionidSub = sessionid;
			if(sessionid.indexOf("!")>-1){
				sessionidSub = sessionid.substring(0, sessionid.indexOf("!"));
			}
			
			if(SessionCacheManager.getCache(msisdn)==null || "".equals(SessionCacheManager.getCache(msisdn))){
				log.info("["+inComeIP+"] Cache is null, call another server to check whether cache exist?");
				boolean hasCache = ConnectionUtil.checkAnotherServerCache(req, msisdn, sessionidSub);
				if(hasCache){
					log.info("["+inComeIP+"] another server still not expire this session, continue.");
					SessionCacheManager.putCache(msisdn, sessionidSub);
				}else{
					log.info("["+inComeIP+"] { another server cache expire too } Or { fail to get cache after 2seconds }, back to login.");
					req.getRequestDispatcher("/login.jsp?JSESSIONID="+sessionid).forward(req, respon);
				}
			}else if(!sessionidSub.equals(SessionCacheManager.getCache(msisdn))){
				log.info("["+inComeIP+"] !!!! Cache not existed, user have logined from another side, back to login page in this side.");
				req.getRequestDispatcher("/login.jsp?JSESSIONID="+sessionid).forward(req, respon);
			}else{
				log.info("["+inComeIP+"] Cache existed, extend expire date.");
				SessionCacheManager.setExpireDateByKey(msisdn, Calendar.MINUTE, 30);
			}
			
			log.info("["+inComeIP+"] msisdn:"+msisdn+"  start logining ...");
			log.info("["+inComeIP+"] this user information msisdn:"+msisdn+"  partyId:"+partyid);
			boolean isPost = false;
			if("POST".equals(req.getMethod()))isPost=true;
			ProxySkipUtil.proxyProcess(session,req, respon, msisdn, partyid,queryStringUrl,CookieID,isPost);
			log.info("["+inComeIP+"] msisdn:"+msisdn+" logined SDF consume: "+(System.currentTimeMillis()-startTime)+" ms");
			log.info("*************************************************************************");
		}else{
			log.info("["+inComeIP+"] session has not information");
			req.getRequestDispatcher("/login.jsp?JSESSIONID="+session.getId()).forward(req, respon);
			
		}
		
		
		
	}
	
	public String getIPAddress(HttpServletRequest request){
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
		{
			ip = request.getHeader("Proxy-Client-IP");
		}

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
		{
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
		{
			ip = request.getRemoteAddr();
		}
		
		int index = ip.indexOf(",");
		if(index != -1){
			return ip.substring(0,index);
		}
		return ip; 
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	}

	
}
