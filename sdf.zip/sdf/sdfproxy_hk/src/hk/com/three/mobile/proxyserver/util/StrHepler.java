package hk.com.three.mobile.proxyserver.util;


import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.ClassUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class StrHepler {
	private static final Log log = LogFactory.getLog(StrHepler.class);
	private static String strDefaultKey = "national";    

	
	
	
	 public static String getImplclassnameByInterclassname(Class interclass){
		 String rtn  = interclass.getName();
		 if(!StringUtils.isBlank(rtn)){
			 String packagename = StringUtils.replace(ClassUtils.getPackageName(interclass), "interfaces", "impl");
			 char[] classname = (ClassUtils.getShortClassName(interclass)+ "Impl").toCharArray();
			 rtn = packagename+"."+new String(classname,1,classname.length-1);
		 }
		 return rtn;
	 }
	 
	 

	 public static String setForwordURL(HttpServletRequest request)
		{
		    String rtn = null;
			StringBuffer requestURL =new StringBuffer(request.getRequestURL());
			String queryString = request.getQueryString();
			log.info("requestURL :"+requestURL.toString());
			log.info("queryString url arg :"+queryString);
			
			
			int index = requestURL.indexOf(request.getContextPath())+request.getContextPath().length();
			rtn = requestURL.toString().substring(index);
			
			if(rtn.equals("/")){
				rtn = rtn + "redir/index.jsp";
				log.info("url is empty, set default value=" + rtn);
			}
			if(queryString!=null)
			{
				rtn = rtn + "?" + queryString;
			}
			
			log.info("transport url :"+rtn);
			if("".equals(rtn) || rtn == null){
				log.info("transport url is null, set to defalt = /redir/index.jsp");
				rtn = "/redir/index.jsp";
			}
			return rtn;
		}
	
	
}
	 
