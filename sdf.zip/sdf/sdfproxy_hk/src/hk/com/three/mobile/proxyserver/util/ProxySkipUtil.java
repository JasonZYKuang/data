package hk.com.three.mobile.proxyserver.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.NDC;

public class ProxySkipUtil {
	private static final Log log = LogFactory.getLog(ProxySkipUtil.class);
	public static void proxyProcess(HttpSession session, HttpServletRequest req,
			HttpServletResponse resp, String msisdn, String partyid,
			String queryStringUrl, String cookieID, boolean isPost) {
		String strSessId = cookieID;
		String productname = queryStringUrl.substring(1);
		if(productname.indexOf("/")>0){
			productname = productname.substring(0,productname.indexOf("/"));
		}
		/*String sessionid = req.getSession().getId();
		String sessionidSub = sessionid;
		if(sessionid.indexOf("!")>-1){
			sessionidSub = sessionid.substring(0, sessionid.indexOf("!"));
		}*/
		
		String url = null;
		Properties properties = null;

		HttpURLConnection huc = null;
		try {
			NDC.push(msisdn);
			properties = Resource.loadPropertiesFromClassPath("config.properties");
			url = properties.getProperty("SDF12_URL").trim();
			if (!StringUtils.isBlank(queryStringUrl))
				url = url + queryStringUrl;
			if (StringUtils.isBlank(url)) {
				log.error("skip URl is null ! please check the config !");
				throw new Exception();
			}
			log.info("SDF URL:" + url);

		//Instance HttpURLConnection
			HttpURLConnection.setFollowRedirects(true);
			huc = (HttpURLConnection) new URL(url).openConnection();
			log.info("user-agent="+req.getHeader("user-agent"));
			log.info("Start set HttpHeader!");
			huc.setRequestProperty("X-H3G-MSISDN", "");
			huc.setRequestProperty("X-H3G-PARTY-ID", "");
			huc.setRequestProperty("X-Forwarded-For", "");
			log.info("Clear HttpHeader Success!");
			log.info("=======================================================================0");
			if(HttpUtil.isNotStatic(queryStringUrl)){
				HttpUtil.setHeaders(req, huc);
			}
			Enumeration<?> headerNames = req.getHeaderNames();
	        String key, val;
	        while (headerNames.hasMoreElements()) {
	            key = (String) headerNames.nextElement();
	            val = req.getHeader(key);
	            log.info(key+"="+val);
	        }
	        log.info("=======================================================================0");
	        
	        if (strSessId !=null && strSessId.indexOf("$")>-1) {
	        	String[] cookies = strSessId.split("\\$");
	    		for(int i=0;i<cookies.length;i++){
	    			log.info("Add Cookie ["+i+"]="+ cookies[i]);
	    			huc.addRequestProperty("Cookie", cookies[i]);
	    		}
            }
	        /*huc.setRequestProperty("User-Agent", req.getHeader("user-agent"));
	        huc.setRequestProperty("Accept", req.getHeader("Accept"));
			huc.setRequestProperty("Accept-Language", req.getHeader("Accept-Language"));
			huc.setRequestProperty("Accept-Charset", properties.getProperty("Accept-Charset"));
			huc.setRequestProperty("Referer", req.getHeader("Referer"));*/
	        huc.setRequestProperty("Accept-Charset", properties.getProperty("Accept-Charset"));
			huc.setRequestProperty("X-H3G-MSISDN", msisdn.length() == 8 ? "852"+ msisdn : msisdn);
			huc.setRequestProperty("X-H3G-PARTY-ID", partyid);
			huc.setRequestProperty("X-H3G-REQUEST-URL", "https://mobile.three.com.hk"+queryStringUrl);
			huc.setRequestProperty("X-H3G-PRODUCT-BASE", "https://mobile.three.com.hk/"+productname);
			
			String xForwardedFor = req.getHeader("X-Forwarded-For");
			log.info("xForwardedFor:" + xForwardedFor);
			if(xForwardedFor==null || xForwardedFor.equals("")){
				xForwardedFor = req.getRemoteAddr();
			}
			huc.setRequestProperty("X-Forwarded-For", xForwardedFor);
			huc.setRequestProperty("X-H3G-CC", properties.getProperty("X-H3G-CC"));
			huc.setRequestProperty("X-H3G-NC", properties.getProperty("X-H3G-NC"));
			huc.setRequestProperty("X-H3G-NETWORK-QUALITY", properties.getProperty("X-H3G-NETWORK-QUALITY"));
			huc.setRequestProperty("X-H3G-ORG-ID", properties.getProperty("X-H3G-ORG-ID"));
			huc.setRequestProperty("X-H3G-ACCT-DATA", properties.getProperty("X-H3G-ACCT-DATA"));
			huc.setRequestProperty("X-H3G-SDFPROXY", properties.getProperty("X-H3G-SDFPROXY"));

			log.info("RemoteHost:" + req.getRemoteHost());
			log.info("RemoteAddr:" + req.getRemoteAddr());
			log.info("Inject HttpHeader Success!");
			log.info("Instance HttpURLConnection Success!");

			//config HttpURLConnection
			log.info("-------------------------------");
			log.info("Start set HttpConnection Config");
			log.info("-------------------------------");
			huc.setInstanceFollowRedirects(false);
			
			huc.setDoInput(true);
            byte[] byteRep = null;
            if (isPost) {
            	log.info("Set Request Method: POST");
                huc.setRequestMethod("POST");
                huc.setDoOutput(true);
               //huc.setUseCaches(false);
            } else {
            	log.info("Set Request Method: GET");
                huc.setRequestMethod("GET");
                huc.setDoOutput(false);
            }
			if(isPost){
				byteRep = HttpUtil.composeParameters(req);
                log.info("It is post and the content-length=[" + String.valueOf(byteRep.length) + "]");
                huc.setRequestProperty("Content-Length", String.valueOf(byteRep.length));
			}
			
			huc.setAllowUserInteraction(false);
			
			if (isPost) {
				log.info("Write byteRep.!");
                OutputStream outputStream = huc.getOutputStream();
                outputStream.write(byteRep);
            }else{
            	huc.connect();
            }
			
			log.info("-----------------------------------------------------------------------2");
			String hkey,hvalue;String cookieVal="";
			for (int n = 0; (hvalue = huc.getHeaderField(n)) != null; ++n) {
				hkey = huc.getHeaderFieldKey(n);
				hvalue = huc.getHeaderField(n);
				log.info(hkey+"="+hvalue);
	            if (hkey != null) {
	                if(hkey.equalsIgnoreCase("Set-Cookie") && strSessId == null ){
	                	cookieVal = cookieVal + hvalue + "$";
	                }
	            }
	            
	        }
			if(strSessId ==null || "".equals(strSessId)){
				if(!"".equals(cookieVal)){
					log.info("cookieVal="+cookieVal);
					/*SessionDBManage sessiondb = new SessionDBManage();
					boolean updateStatus = sessiondb.updateCookie(msisdn,sessionidSub,cookieVal);
					log.info("Update cookie:"+updateStatus);*///YU remaked for DB.
					session.removeAttribute("CookieID");
					session.setAttribute("CookieID", cookieVal);
					
				}
			}else{
				log.info("strSessId not null, no need setAttribute.");
			}
			log.info("-----------------------------------------------------------------------2");
			
			
			log.info("Connection SDF URL Success!");
			long starttime = System.currentTimeMillis();

			int responseStatusCode = huc.getResponseCode();
			log.info("HTTP Status code : " + responseStatusCode);
			log.info("Http Response Message: " + huc.getResponseMessage());

			OutputStream os = resp.getOutputStream();
			if (responseStatusCode == HttpURLConnection.HTTP_OK) {
				HttpUtil.setHeaders(resp, huc);
				
				/*InputStream is = huc.getInputStream();
				int data;
				int left = is.available();*/
	                
				String strContentType = huc.getContentType();
				if (strContentType == null) {
                    strContentType = "";
                    resp.setContentType("application/x-www-form-urlencoded");
                    log.info("Response Content-Type=[" + "application/x-www-form-urlencoded" + "] due to contentType is null");
                } else if (strContentType.length() == 0) {
                    resp.setContentType("application/x-www-form-urlencoded");
                    log.info("Response Content-Type=[" + "application/x-www-form-urlencoded" + "] due to contentType is empty");
                } else {
                    resp.setContentType(strContentType);      //application/vnd.wap.xhtml+xml;charset=UTF-8
                    log.info("Response Content-Type=[" + strContentType + "]");
                }
				
				/*if (!(strContentType.indexOf("text/html") >= 0)) {
                    //We return the content to SDF directly if this page isn't a static page.
                    log.info("++ Return Normal, response length=[" + left + "] ++");
                    ServletOutputStream out = resp.getOutputStream();
                    while ((data = is.read()) != -1) out.write(data);
                    out.close();
                } else {
                    //We will analyze this page if this page is a static html or jsp page.
                    log.info("++ response length=[" + left + "] ++");

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    while ((data = is.read()) != -1) baos.write(data);
                    String strContent = new String(baos.toByteArray(), "utf-8");
                    baos.close();


                    byte[] strContentInByte = strContent.getBytes("utf-8");
                    log.info("Write total byte=[" + strContentInByte.length + "] to output");

                    ServletOutputStream out = resp.getOutputStream();
                    out.write(strContentInByte, 0, strContentInByte.length);
                    out.close();
                }*/
				

				InputStream targetIS = null;
				try {
					targetIS = huc.getInputStream();
				} catch (Exception e1) {
					log.error("HttpURLConnection getInputStream error:", e1);
					targetIS = huc.getErrorStream();
				}
				log.info("In-Outputstream create time :"+ (System.currentTimeMillis() - starttime) + "ms");
				
				/*
				//modify by xiao 2014-4-8  change http:// to https://
				String filterpage = "andplanet/f.html";
				if(queryStringUrl.contains(filterpage)){
					int DEFAULT_BUFFER_SIZE = 1024 * 4;
					byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
					long count = 0;
					int n = 0;
					while (-1 != (n = targetIS.read(buffer))) {
						String str = new String(buffer, 0, n);
						 str = StringUtils.replace(str, "http://mobile.three.com.hk", "https://mobile.three.com.hk");
						 os.write(str.getBytes());
						 count += n;
					 }
					log.info("read count=" + count);
					log.info(filterpage + " replace http end....................................");
					log.info("Write time :"+ (System.currentTimeMillis() - starttime) + "ms");
					
				}else{
					int r;
					int count = 0;
					while ((r = targetIS.read()) != -1) {
						os.write(r);
						count++;
					}
					log.info("read count=" + count);
					log.info("Write time :"+ (System.currentTimeMillis() - starttime) + "ms");
				}*/
				
				int r;
				while ((r = targetIS.read()) != -1) {
					os.write(r);
				}
				targetIS.close();
				
				
				
				/*InputStream targetIS = null;
				try {
					targetIS = huc.getInputStream();
				} catch (Exception e1) {
					log.error("HttpURLConnection getInputStream error:", e1);
					targetIS = huc.getErrorStream();
				}
				log.info("In-Outputstream create time :"+ (System.currentTimeMillis() - starttime) + "ms");
				int r;
				while ((r = targetIS.read()) != -1) {
					os.write(r);
				}
				targetIS.close();*/
			} else if(responseStatusCode == HttpURLConnection.HTTP_MOVED_TEMP || responseStatusCode == 307
                                || responseStatusCode == HttpURLConnection.HTTP_MOVED_PERM) {
				log.info("Set response status " + responseStatusCode);
				resp.setStatus(responseStatusCode);
				String redirectUrl = huc.getHeaderField("location");
				log.info("Redirect URL : " + redirectUrl);

				int replace_detect_num = Integer.parseInt(properties.getProperty("RedirectUrl_Replace_Number").trim());
				for (int i = 1; i <= replace_detect_num; i++) {
					String replace_key = properties.getProperty("URL_startWith_" + i).trim();
					if (redirectUrl.startsWith(replace_key)) {
						String replace_value = properties.getProperty("URL_replactTo_" + i).trim();
						log.debug("URL_replactTo_" + i + " = " + replace_value);
						redirectUrl = replace_value 
								+ req.getContextPath()
								+ redirectUrl.substring(replace_key.length());
						log.debug("UredirectUrl = " + redirectUrl);
					}
				}
				log.info("Replace Redirect URL to: " + redirectUrl);
				resp.sendRedirect(redirectUrl);
			}else{
				log.error("Exception while response code = "+responseStatusCode);
			}
			log.info("Inputstream close time :"+ (System.currentTimeMillis() - starttime) + "ms");
			//os.flush();
			log.info("Outputstream close time 1 :"+ (System.currentTimeMillis() - starttime) + "ms");
		    //os.close();
			log.info("Outputstream close time 2 :"+ (System.currentTimeMillis() - starttime) + "ms");
			//huc.disconnect();
		} catch (Exception e) {
			log.error("Proxy Skip  Fail :  "+e.getStackTrace());
			log.error(e.getMessage());
			e.printStackTrace();
		}finally{
			if (huc != null) huc.disconnect();
			log.info("--------- Start pop Log4J NDC stack.");
			try {
	            while (NDC.getDepth() != 0) {
	                NDC.pop();
	            }
	        }
	        catch (Exception e) {
	            log.error("Error popping message ID off of Log4J NDC stack.", e);
	        }
		}

	}
	//}
	
}
