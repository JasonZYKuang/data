package com.byxx.test;

public class Keys {

	public static final String APP_ID = "7568555";

	public static final String API_KEY = "G8AgysV0QbrXcylSpsKzwLRk";

	public static final String SECRET_KEY = "6M413qFkc4u0vuA9ed1vdcEOAOBHvhat";
}
