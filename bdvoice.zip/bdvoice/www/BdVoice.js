
cordova.define("cordova/plugins/BdVoice", 
  function(require, exports, module) {
    var exec = require("cordova/exec");
    var BdVoice = function() {};
	  BdVoice.prototype.speakout = function(inputText,successCallback, errorCallback) {
        
        if (typeof errorCallback != "function")  {
            console.log("error");
            return
        }
    
        if (typeof successCallback != "function") {
            console.log("error");
            return
        }
        exec(successCallback, errorCallback, 'BdVoice', 'speakout', [{"text":inputText}]);
    };
	
    var BdVoice = new BdVoice();
    module.exports = BdVoice;

});

  
if(!window.plugins) {
    window.plugins = {};
}
if (!window.plugins.BdVoice) {
    window.plugins.BdVoice = cordova.require("cordova/plugins/BdVoice");
}