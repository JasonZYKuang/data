angular.module('starter.services', ['ab-base64', 'LocalForageModule'])

/***
 * dwnstatus:
 *            success: 已下载
 *            downing: 下载中
 *            waiting: 等待下载
 *            pause: 暂停下载
 *            download: 下载
 */
  .value("langlist", {
    YANGJIANG: {id: 'YANGJIANG', name: '阳江话', size: "29.7M", dwnstatus: 'download', progressval: 0, stopinterval: null},
    KEJIA: {id: 'KEJIA', name: '客家话', size: "30M", dwnstatus: 'download', progressval: 0, stopinterval: null},
    CHAOSHAN: {id: 'CHAOSHAN', name: '潮汕话', size: "25M", dwnstatus: 'download', progressval: 0, stopinterval: null},
    LEIZHOU: {id: 'LEIZHOU', name: '雷州话', size: "20M", dwnstatus: 'download', progressval: 0, stopinterval: null}
  })

  .value("lang_dialogues", {
    YANGJIANG: {id: 'YANGJIANG', name: '阳江话', size: "29.7M", dwnstatus: 'download', progressval: 0, stopinterval: null},
    KEJIA: {id: 'KEJIA', name: '客家话', size: "30M", dwnstatus: 'download', progressval: 0, stopinterval: null},
    CHAOSHAN: {id: 'CHAOSHAN', name: '潮汕话', size: "25M", dwnstatus: 'download', progressval: 0, stopinterval: null},
    LEIZHOU: {id: 'LEIZHOU', name: '雷州话', size: "20M", dwnstatus: 'download', progressval: 0, stopinterval: null}
  })


  .factory('$localstorage', ['$window', function ($window) {
    return {
      set: function (key, value) {
        $window.localStorage[key] = value;
      },
      get: function (key, defaultValue) {
        return $window.localStorage[key] || defaultValue;
      },
      setObject: function (key, value) {
        $window.localStorage[key] = JSON.stringify(value);
      },
      getObject: function (key) {
        console.log('key ' + $window.localStorage[key]);
        return JSON.parse($window.localStorage[key] || null);
      }
    }
  }])

  .factory('ServerData', function ($ionicPopup, $timeout) {
    return {
      //弹出信息框
      alert: function (msg) {
        $ionicPopup.alert({
          template: msg,
          title: '提示信息'
        });
      },
      alertBy: function (tle, msg) {
        $ionicPopup.alert({
          template: msg,
          title: tle
        });
      },

      showPopup: function (value) {
        var myPopup = $ionicPopup.show({
          cssClass: 'er-popup',
          content: value
        });

        $timeout(function () {
          myPopup.close();
        }, 1000);
      }
    };
  })

  .factory('RecognitionService', function ($http, $q, $cordovaDevice, base64, $window, $ionicLoading) {
    return {
      recognise: function (data) {
        console.log(data.length);
        var uuid = $cordovaDevice.getUUID();
        console.log("uuid=" + uuid);
        var defer = $q.defer();

        //获取 access_token

        $ionicLoading.show({
          content: 'Loading',
          animation: 'fade-in',
          showBackdrop: true,
          maxWidth: 200,
          showDelay: 0
        });


        //判断是否存在百度 access_token

        var access_token = $window.localStorage['bd_access_token'] || '';
        var token_data = $window.localStorage['bd_token_data'] || '';

        if (access_token == '' || token_data == '') {

          $http({
            method: 'POST',
            url: 'https://openapi.baidu.com/oauth/2.0/token',
            params: {
              'grant_type': 'client_credentials',
              'client_id': 'aDMbGya9mZU9CFHrP56S4MLf',
              'client_secret': '5cdeca5413ea8652098be1c8b6d1d522'
            },
            dataType: 'json'
          }).success(function (data) {

            $window.localStorage['bd_access_token'] = data.access_token;

            $window.localStorage['bd_token_data'] = new Date().toDateString();

          }).error(function () {
            $ionicLoading.hide();
          });

        } else {

          var date1 = new Date(token_data);

          var date2 = new Date();

          var time = date2.getTime() - date1.getTime();

          if (time / (1000 * 3600 * 24) > 30) {

            $http({
              method: 'POST',
              url: 'https://openapi.baidu.com/oauth/2.0/token',
              params: {
                'grant_type': 'client_credentials',
                'client_id': 'aDMbGya9mZU9CFHrP56S4MLf',
                'client_secret': '5cdeca5413ea8652098be1c8b6d1d522'
              },
              dataType: 'json'
            }).success(function (data) {

              $window.localStorage['bd_access_token'] = data.access_token;

              $window.localStorage['bd_token_data'] = new Date().toDateString();

            }).error(function () {
              $ionicLoading.hide();
            });

          }

        }
        console.log('lang:' + voice_lang);

        $http({
          method: 'POST',
          url: 'http://vop.baidu.com/server_api/',
          data: data,
          headers: {
            'Content-Type': 'audio/amr;rate=8000'
          },
          params: {
            lan: voice_lang,
            token: $window.localStorage['bd_access_token'],
            cuid: uuid
          },
          transformRequest: []
        }).success(function (data) {

          $ionicLoading.hide();
          defer.resolve(data);
        }).error(function (data, status, headers, config) {
          $ionicLoading.hide();
          defer.reject(data);
        });
        return defer.promise;
      },


      translate: function (string) {

        var salt = Math.random();

        var appid = '20161026000030789';

        var key = 'Q5yOhyev3262RLc3rKgn';

        var sign = hex_md5(appid + string + salt + key);

        var defer = $q.defer();

        //翻译服务
        $http({
          method: 'POST',
          url: 'http://api.fanyi.baidu.com/api/trans/vip/translate',
          params: {
            'q': string,
            'from': 'auto',
            'to': 'zh',
            'appid': appid,
            'salt': salt,
            'sign': sign
          },
          dataType: 'json'
        }).success(function (data) {

          defer.resolve(data);

        }).error(function () {
          $ionicLoading.hide();
          defer.reject(data);
        });

        return defer.promise;


      }
    };
  })

  .factory('FileService', function ($q, $window) {
    return {
      readAsArrayBuffer: function (file) {
        console.log("file=" + file);
        var defer = $q.defer();
        $window.resolveLocalFileSystemURL(file, function (entry) {
          var reader = new $window.FileReader();
          reader.onload = function (evt) {
            defer.resolve(evt.target.result);
            console.log("evt target=" + evt.target.result);
          }
          reader.onerror = function (evt) {
            defer.reject();
          };
          entry.file(function (s) {
            console.log("s.size=" + s.size);

            //reader.readAsArrayBuffer(s);
            // reader.readAsDataURL(s);
            reader.readAsArrayBuffer(s);
          });
        });
        return defer.promise;
      }
    };
  })

  .factory('VoiceRecorderService', function ($http, $ionicPopup, $q, $window, $timeout, $rootScope,$cordovaMedia) {
    console.log("voice reord service");
    var recording, record,
      recordCanceled, maxLengthCheckTimeout;

    /*var mediaSrc = window.cordova.file.externalDataDirectory + "dialect.wav";
     var mediaSource = new NewMedia(mediaSrc, function () {
     }, function () {
     }, function () {
     });*/

    return {
      startRecord4IOS: function (maxLength) {
        var recordSettings = {
          "SampleRate": 8000,
          "NumberOfChannels": 1,
          "LinearPCMBitDepth": 16
        };
        var defer = $q.defer();
        //var dir = cordova.file.dataDirectory ;
        var dir = "documents://";
        var file = "documents://test.wav";
        console.log("startRecord 4 ios docxxx =" + file);
        this.resetState();

        dir.getFile(
            "test.wav",
            {create:true,exclusive:false},
            function(fileEntry){
              //实例化录音类
              var record = new Media(file,
                  function() {//录音执行函数
                    if (recordCanceled) {
                      defer.reject({reason: "canceled"});
                    }
                    else {
                      defer.resolve(file);
                    }
                  },
                  function(err) {//录音失败执行函数
                    defer.reject({reason: "failed"});
                    console.log("record failed.");
                  }
              );
            },function(){
            }
        );

        if (angular.isDefined(maxLength)) {
          maxLengthCheckTimeout = $timeout(function exceedMaxLengthCallback() {
            record.stopRecord();
          }, maxLength * 1000);
        };
        return defer.promise;
      },


      //弹出信息框
      startRecord: function (maxLength) {
        var recordSettings = {
          "SampleRate": 8000,
          "NumberOfChannels": 1,
          "LinearPCMBitDepth": 16
        };
        var defer = $q.defer();
        var file = '';
        if (ionic.Platform.isAndroid()) {
          file = cordova.file.externalDataDirectory + "fy.amr";
        }else if(ionic.Platform.isIOS()){
          //file = cordova.file.dataDirectory + "fy.wav";
          //file = cordova.file.applicationStorageDirectory + "Library/files/fy.wav"
          //file = "cdvfile://localhost/persistent/" + "fy.wav";
          file = "documents://fy.wav";
        }
        console.log("startRecord old =" + file);
        this.resetState();
        record = new Media(file,
        //record = $cordovaMedia.newMedia(file,
          function () {
            if (recordCanceled) {
              defer.reject({reason: "canceled"});
            }
            else {
              defer.resolve(file);
            }
          },
          function (error) {
            defer.reject({reason: "failed"});
            console.log("record failed.");
          }
        );

        if (angular.isDefined(maxLength)) {
          maxLengthCheckTimeout = $timeout(function exceedMaxLengthCallback() {
            record.stopRecord();
          }, maxLength * 1000);
        }
        ;
        return defer.promise;
      },
      stopRecord: function () {
        $timeout.cancel(maxLengthCheckTimeout);
        record.stopRecord();
      },
      cancelRecord: function () {
        $timeout.cancel(maxLengthCheckTimeout);
        recordCanceled = true;
        record.stopRecord();
        //record.stopRecordWithSettings();
        // TODO: 删除文件
      },
      resetState: function () {
        recording = false;
        record = null;
        recordCanceled = false;
        maxLengthCheckTimeout = null;
      }

    };

    /*var data = [];
     var params = null;
     var file = "../data/audio/nihao.wav";
     var reader = new FileReader();


     params = {
     "headers": {
     'Content-Type': 'audio/amr; rate=8000'
     },
     "format": "wav",
     "rate": 8000,
     "channel": 1,
     cuid: "com.test.myapp",
     token: "24.cac3afd6cb4710204df36be96702458c.2592000.1465613998.282335-8114838",
     //speech: temp,
     len: file.size,
     lan: "ct"
     };
     return{
     postMedia: function() {
     data = $http.post("http://vop.baidu.com/server_api", params);
     console.log("data="+data);
     return data;
     }
     };*/
  })


  .factory('DialogueService', function ($http, $q,$ionicLoading,downloadService) {
    // Might use a resource here that returns a JSON array

    // Some fake testing data
    var dialogues = [];
    /*var dialogues =
     $http.get("data/json/dialogues.json").success(function(response){
     //dialogues = response.data.results;
     });*/

    return {
      setDia: function (data) {
        dialogues = [];
        dialogues = data;
      },
      getDia: function () {
        return dialogues;
      },
      init: function (langId) {
        var server_url;
        if(downloadService.hasDownloaded(langId)){
          if (ionic.Platform.isAndroid()) {
            server_url = cordova.file.externalDataDirectory + "/" + langId + "/dialogues/dialogue_" + langId + ".json";
          }else if(ionic.Platform.isIOS()){
            server_url = cordova.file.applicationStorageDirectory + "Library/files/" + langId + "/dialogues/dialogue_" + langId + ".json";
          }
        }else{
          server_url = server + "/" + langId + "/dialogues/dialogue_" + langId + ".json";
        }
        //var server_url = server + "/" + langId + "/dialogues/dialogue_" + langId + ".json";
        $ionicLoading.show();
        var defer = $q.defer();
        $http({
            url: server_url,
            method: 'get',
            timeout: 1000
          }).success(function (data) {
            $ionicLoading.hide();
            defer.resolve(data);
          }).error(function () {
            $ionicLoading.hide();
            /*$ionicPopup.alert({
              template: '网络未连接，请连接WIFI下载离线翻译数据包',
              title: '提示信息'
            });*/
          })
          return defer.promise;
      },
      all: function (langId) {
        //dialogues = $http.get("data/json/dialogue_"+langId+".json", {cache: true});
        var path = ''
        if (window.cordova) {
          path = cordova.file.externalApplicationStorageDirectory
        }
        dialogues = $http.get(path + langId + "/dialogues/dialogue_" + langId + ".json", {cache: true});

        return dialogues;
      },
      all_live: function (langId) {
        var server_url;
        if(downloadService.hasDownloaded(langId)){
          if (ionic.Platform.isAndroid()) {
            server_url = cordova.file.externalDataDirectory + "/" + langId + "/dialogues/dialogue_" + langId + ".json";
          }else if(ionic.Platform.isIOS()){
            server_url = cordova.file.applicationStorageDirectory + "Library/files/" + langId + "/dialogues/dialogue_" + langId + ".json";
          }
        }else{
          server_url = server + "/" + langId + "/dialogues/dialogue_" + langId + ".json";
        }
        //var server_url = server + "/" + langId + "/dialogues/dialogue_" + langId + ".json";
        dialogues = $http.get(server_url,{cache: true});
        return dialogues;

      },


      get: function (dialogueId) {
        // Simple index lookup
        return dialogues[dialogueId];
      }
    };
  })


  .factory('TranslateService', function ($http, $q, $localForage, langlist, lang_dialogues,downloadService,$ionicPopup) {

    return {
      getNamebyId: function (langId) {
        return langlist[langId].name;
        /*for (var i = 0; i < langlist.length; i++) {

         if (langlist[i].id === langId) {
         return langlist[i].name;
         }
         }
         return null;*/
      },
      hasLang: function (langId) {
        if (langlist[langId].dwnstatus == 'success')
          return true;
        else return false;
        /*for (var i = 0; i < OfflineData.lang.length; i++) {
         if (OfflineData.lang[i] === langId) {
         return true;
         }
         }
         return false;*/
      },
      hasDialogues: function (langId) {
        if (lang_dialogues[langId].dwnstatus == 'success')
          return true;
        else return false;
      },
      load: function (lang) {
        var filePath = '';
        if (window.cordova) {
          filePath = cordova.file.externalApplicationStorageDirectory;
          console.log("filepath=" + filePath);
        }
        $http.get(filePath + lang + '/translate/trans' + lang + '.json', {cache: true})
          .success(function (data) {
            for (var i in data) {
              $localForage.setItem('trans_' + lang + '_' + data[i].name, JSON.stringify(data[i].value), function (result) {
                //console.log(result);
              });
            }
            //OfflineData.lang.push(lang);
          }).error(function (err) {

        });
      },
      translate: function (data, lang) {
        var defer = $q.defer();
        var result = new Array();
        var src = data.split(" ");
        for (var s in src) {
          (function (s) {
            var cnChar = src[s].match(/[^\x00-\x80]/g);
            if (cnChar != null) {
              for (var c in cnChar) {
                (function (c) {
                  var val = $localForage.getItem('trans_' + lang + '_' + cnChar[c]);
                  result.push(val);
                })(c)
              }
            } else {
            }
          })(s)

        }
        $q.all(result).then(function (resp) {
          defer.resolve(resp);
        });
        return defer.promise;
      },
      translateLive: function (data, lang, callback , network) {

        var result = [];
        var hasNetwork = true;
        var server_url;

        if(downloadService.hasDownloaded(lang)){
          console.log(lang + "has downloaded !!!!!!!!!!!!");
          if (ionic.Platform.isAndroid()) {
            server_url = cordova.file.externalDataDirectory + "/" + lang + "/translate/trans_" + lang + ".json";
          }else if(ionic.Platform.isIOS()){
            server_url = cordova.file.applicationStorageDirectory + "Library/files/" + lang + "/translate/trans_" + lang + ".json";
          }
        }else{
          server_url = server + "/" + lang + "/translate/trans_" + lang + ".json";
        }
        console.log("server_url = "+ server_url);

        $http({
          'method': 'get',
          'url': server_url,
          'type': 'json',
          'timeout': 1500
        }).success(function (voices) {

          var src = data.split(" ");
          for (var s in src) {
            (function (s) {
              var cnChar = src[s].match(/[^\x00-\x80]/g);
              if (cnChar != null) {
                for (var c in cnChar) {
                  (function (c) {

                    voices.forEach(function (voice) {

                      if (voice['name'] == cnChar[c]) result.push(JSON.stringify(voice['value']));

                    });

                  })(c)
                }
              } else {
              }
            })(s)
          }

          callback(result);

        }).error(function (resp){
          console.log(resp);
          hasNetwork = false;
          //network(hasNetwork);
        });

      }
    };
  })


  /*.factory('HistoryService', function ($localForage) {
   return {
   addData: function () {
   if($scope.storedData.length >= 10){
   this.removeData(0);
   }
   $scope.storedData.push($scope.translate.message);
   localforage.setItem('storedDataForage', $scope.storedData).then(function(value) {
   console.log($scope.translate.message + ' was added!');
   }, function(error) {
   console.error(error);
   });
   },
   removeData: function (index) {
   $scope.storedData.splice(index, 1);
   localforage.setItem('storedDataForage', $scope.storedData);
   },
   clearData: function(){
   console.log("clear history");
   $scope.storedData = [];
   localforage.setItem('storedDataForage', $scope.storedData);
   }
   };
   })*/


  .factory('netWorkService', function ($http, $ionicPopup) {
    return {
      check: function (type) {

        if (typeof (cordova) != "undefined") {

          $http({
            url: 'http://www.baidu.com',
            method: 'get',
            timeout: 1000
          }).success(function (data) {
          }).error(function () {
            $ionicPopup.alert({
              template: (type == 0) ? '网络不可用' : '网络未连接，请连接WIFI下载离线翻译数据包',
              title: '提示信息'
            });
          })

        }


      }
    };
  })

    .factory('downloadService', function ($http, $q, $ionicPopup, $ionicLoading,downloadlist) {
      return {
        check: function () {
            $ionicLoading.show();
            var defer = $q.defer();
            $http({
              url: server + 'download.json',
              method: 'get',
              timeout: 1000
            }).success(function (data) {
               $ionicLoading.hide();
               defer.resolve(data);
            }).error(function () {
              $ionicLoading.hide();
              $ionicPopup.alert({
                template: '网络未连接，请连接WIFI下载离线翻译数据包',
                title: '提示信息'
              });
            })
          return defer.promise;

        },
        hasDownloaded: function (langId) {
          var result = false;
          if(downloadlist.length > 0 ){
            for(var i in downloadlist){
              if(downloadlist[i].id == langId){
                result = true;
                break;
              }
            }
          }
          return result;
        }
      };
    })

  .factory('advanceService', function ($http, $ionicPopup) {

    return {

      send: function (msg) {

        $http({
          url: "http://120.24.158.176:8080/demo/Feedback?txt=" + msg,
          method: 'get',
          timeout: 1000
        }).success(function () {
        }).error(function () {

          $ionicPopup.alert({
            template: '网络不可用',
            title: '提示信息'
          });


        });

      }


    };

  });
