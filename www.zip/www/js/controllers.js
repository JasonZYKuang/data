var voice_lang = 'zh';
var isLive = 0;
angular.module('starter.controllers', [])
  .controller('TabsCtrl', function ($scope, $state, $ionicTabsDelegate) {

    $scope.goForward = function () {
      var selected = $ionicTabsDelegate.selectedIndex();
      if (selected != -1) {
        $ionicTabsDelegate.select(selected + 1);
      }
    }

    $scope.goBack = function () {
      var selected = $ionicTabsDelegate.selectedIndex();
      if (selected != -1 && selected != 0) {
        $ionicTabsDelegate.select(selected - 1);
      }
    }


      $scope.tabList = [
        'tab.dash',
        'tab.yuyin',
        'tab.dialogues',
        'tab.setting'
      ];

      $scope.onSwipeLeft = function() {
        for(var i=0; i < $scope.tabList.length; i++) {
          if ($scope.tabList[i] == $state.current.name && i != $scope.tabList.length){
            $state.go($scope.tabList[i+1]);
            break;
          }
        }
      };

      $scope.onSwipeRight = function() {
        for(var i=0; i < $scope.tabList.length; i++) {
          if ($scope.tabList[i] == $state.current.name && i != 0){
            $state.go($scope.tabList[i-1]);
            break;
          }
        }
      };

      $scope.$on('$ionicView.enter', function() {
        for(var i=0; i < $scope.tabList.length; i++) {
          if ($scope.tabList[i] == $state.current.name){
            $scope.activeTab = i;
            break;
          }
        }
      });

    })


  .controller('DashCtrl', function ($scope, $timeout, $ionicPopup, ServerData, TranslateService,
                                    lang, $ionicModal, $ionicListDelegate, $ionicLoading, netWorkService, $ionicPlatform) {

    /*$ionicPlatform.ready(function () {
      netWorkService.check(0);
    });*/


    $scope.lang = lang;
    $scope.model = {message: ""};
    $scope.translate = {message: "", result: []};
    $scope.hideLogo = function () {
      $scope.logoHide = true;
      $scope.hasTranslate = false;
    };
    $scope.showLogo = function () {
      $scope.logoHide = false;
    };
    $scope.close = function () {
      $scope.model.message = "";
      $scope.logoHide = false;
      $scope.hasTranslate = false;
    };
    $scope.loadMore = function () {
      $scope.$broadcast('scroll.infiniteScrollComplete');
    };
    $scope.clear = function () {
      $scope.model.message = "";
      $scope.hasTranslate = false;
      $scope.logoHide = false;
      ///$scope.close();
    };
    $scope.translate = function () {
      $scope.translate.result = [];
      $scope.play_icon = true;
      $scope.play_icon2 = false;
      // if (!TranslateService.hasLang($scope.lang.id)) {
      //   ServerData.alert('请前往设置窗口下载数据包:&nbsp;' + $scope.lang.name);
      // } else

      isLive = 0;

      if ($scope.model.message.trim() == '') {
        ServerData.alert('翻译内容不能为空。');
      } else {

        $scope.translate.message = $scope.model.message;
        //$scope.model.message = "";
        //$scope.logoHide = false;
        this.addData();
        $ionicLoading.show();


        if (TranslateService.hasLang($scope.lang.id)) {

          var promise = TranslateService.translate($scope.translate.message, $scope.lang.id);
          promise.then(function (data) {
            var test = [];
            for (var i in data) {
              if (data[i] != null) {
                test.push(data[i])
              } else {
                //test.push("null");
              }
            }
            test = "[" + test + "]";
            console.log("test=" + test);
            $timeout(function () {
              $scope.hasTranslate = true;
              $scope.translate.result = JSON.parse(test);
              $ionicLoading.hide();
            }, 500);
          });
        } else {

          TranslateService.translateLive($scope.translate.message, $scope.lang.id, function (items) {
            isLive = 1;

            var data = [];
            items.forEach(function (item) {
              if (item != null)data.push(item);
            });

            data = "[" + data + "]";
            $timeout(function () {
              $scope.hasTranslate = true;
              $scope.translate.result = JSON.parse(data);
              $ionicLoading.hide();
            }, 500);

          });
        }

      }


    };
    $scope.resub = function () {
      $scope.hasTranslate = false;
    };
    $scope.reTranslate = function (index) {
      var idx = $scope.storedData.length - index - 1;
      $scope.model.message = $scope.storedData[idx];
      this.translate();
    };

    //var audio = document.getElementById('fr').contentWindow.document.getElementById('audio');
    var audio = document.getElementById('myaudio');
    var timer;
    var j;
    $scope.playAudio = function () {
      j = 0;
      $scope.play_icon = false;
      $scope.play_icon2 = true;

      var medias = $scope.translate.result;
      $scope.audioLength = medias.length;
      if (medias.length > 0) {
        if (isLive == 1) {
          audio.src = server + medias[0].audio;
        } else {
          audio.src = cordova.file.externalApplicationStorageDirectory + "translate/" + medias[0].audio;
        }
        audio.play();
        audio.playbackRate = 1.5;

      }

      /*setTimeout(function () {
        console.log("timeout,"+endTime);
        $scope.play_icon = true;
      }, endTime);*/

    };

    audio.addEventListener('ended', function () {
      j++;
      $scope.$apply(function () {
        console.log("j="+j);
        if (j < $scope.audioLength) {
          if (isLive == 1) {
            audio.src = server + $scope.translate.result[j].audio;
          } else {
            audio.src = cordova.file.externalApplicationStorageDirectory + "translate/" + $scope.translate.result[j].audio;
          }
          audio.play();
          audio.playbackRate = 1.5;
        }else{
          console.log("end.")
          $scope.play_icon2 = false;
          setTimeout(function () {
            $scope.play_icon = true;
          }, 1450);
        }

      });
    }, false);

    $scope.$on('$ionicView.enter', function () {
      console.log("dash enter");
      localforage.getItem('storedDataForage', function (err, value) {
        if (err) {
          $scope.storedData = [];
        } else if (value == null) {
          localforage.setItem('storedDataForage', []);
          $scope.storedData = [];
        } else {
          $scope.storedData = value;
        }
      });
    });

    $scope.$on('$ionicView.beforeLeave', function () {
      console.log("leave");
      audio.pause();
      $scope.play_icon = true;
      $scope.play_icon2 = false;

    });
    //Add data to localForage
    $scope.addData = function () {
      if ($scope.storedData.length >= 10) {
        this.removeData(9);
      }
      $scope.storedData.push($scope.translate.message);
      localforage.setItem('storedDataForage', $scope.storedData).then(function (value) {
        //console.log($scope.translate.message + ' was added!');
      }, function (error) {
        console.error(error);
      });
    };

    //Remove data to localForage
    $scope.removeData = function (index) {
      var idx = $scope.storedData.length - index - 1;
      console.log("index=" + index + ",idx=" + idx);
      $scope.storedData.splice(idx, 1);
      $ionicListDelegate.closeOptionButtons();
      localforage.setItem('storedDataForage', $scope.storedData);
    };
    $scope.clearData = function () {
      console.log("clear history");
      $scope.storedData = [];
      localforage.setItem('storedDataForage', $scope.storedData);
    };

    //Modal................................................................
    $ionicModal.fromTemplateUrl('templates/lang.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function (modal) {
      $scope.modal = modal;
    })
    $scope.openModal = function () {
      $scope.modal.show();
    }
    $scope.sltLang = function () {
      lang.name = TranslateService.getNamebyId(lang.id);
      $scope.lang = lang;
      localforage.setItem('lang', {id: lang.id, name: lang.name});
      $scope.modal.hide();
      /* if (TranslateService.hasLang(lang.id)) {
       } else {
       ServerData.alert('请前往设置窗口下载数据包:&nbsp;' + lang.name);
       }*/
    };
    $scope.$on('$destroy', function () {
      $scope.modal.remove();
    });
  })

  .controller('DialoguesCtrl', function ($http, $scope, $state, $ionicModal, ServerData,
                                         TranslateService, DialogueService, DialogueLang, netWorkService, $rootScope) {
    $scope.DialogueLang = DialogueLang;
    console.log("dialoguelang="+DialogueLang.id);
    if (TranslateService.hasLang(DialogueLang.id)) {
      isLive = 0;
      DialogueService.all(DialogueLang.id).success(function (response) {
        DialogueService.setDia(response.results);
        $scope.dialogues = response.results;
      }).error(function () {

      });

    } else {
      DialogueService.all_live(DialogueLang.id).success(function (response) {
        isLive = 1;
        DialogueService.setDia(response.results);
        $scope.dialogues = response.results;
      });
    }


    $scope.gotoDetail = function (dialogueId) {
      $state.go("tab.dialogue-detail", {dialogueId: dialogueId});
    };

    /*Modal                        ************************************************************************/
    $ionicModal.fromTemplateUrl('templates/lang-dialogue.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function (modal) {
      $scope.modal = modal;
    });

    $scope.openModal = function () {
      $scope.modal.show();
    };

    $scope.sltLang = function () {
      DialogueLang.name = TranslateService.getNamebyId(DialogueLang.id);
      $scope.DialogueLang = DialogueLang;
      localforage.setItem('lang_dia', {id: DialogueLang.id, name: DialogueLang.name});
      $scope.modal.hide();
      if (TranslateService.hasDialogues(DialogueLang.id)) {
        isLive = 0;
        DialogueService.all(DialogueLang.id).success(function (response) {
          DialogueService.setDia(response.results);
          $scope.dialogues = response.results;
        }).error(function () {

        });
      } else {
        DialogueService.all_live(DialogueLang.id).success(function (response) {
          isLive = 1;
          DialogueService.setDia(response.results);
          $scope.dialogues = response.results;

        });

      }
    };
    $scope.$on('$destroy', function () {
      $scope.modal.remove();
    });
    /*Modal                        ************************************************************************/

  })

  .controller('DialogueDetailCtrl', function (DialogueLang, $scope, $stateParams, DialogueService, $timeout, Speed, $rootScope) {
    $scope.dialogue = DialogueService.get($stateParams.dialogueId);
    $scope.details = $scope.dialogue.subList;
    $scope.DialogueLang = DialogueLang;
    $scope.play_icon = [];
    $scope.play_icon2 = [];

    var testAudio;
    var audio = document.getElementById('fr').contentWindow.document.getElementById('audio');
    //$scope.details = DialogueService.get($stateParams.dialogueId).subList;

    $scope.playfor = function (id, subAudio, key) {

      $scope.play_icon[id] = false;
      $scope.play_icon2[id] = true;

      $scope.detail_subid = id;
      $scope.index = key;

      var audio_url = '';
      if (isLive == 1) {
        audio_url = server + "/" + subAudio;
      } else {
        audio_url = cordova.file.externalApplicationStorageDirectory + "dialogues/" + subAudio;
      }


      /*testAudio = new Audio(audio_url);
      testAudio.playbackRate = Speed.value;
      console.log('testAudio.playbackRate = ' + testAudio.playbackRate);
      testAudio.play();
      testAudio.addEventListener('ended', function () {
        $timeout(function () {
          $scope.play_icon[id] = true;
        }, 1500);
        $scope.play_icon2[id] = false;
      }, false);*/

      audio.src = audio_url;
      audio.playbackRate = Speed.value;
      audio.play();
      audio.addEventListener('playing',function(){
        console.log("audio playing");
      },false);

      audio.addEventListener('ended', function () {
        $scope.$apply(function () {
          $scope.play_icon[id] = true;
          $scope.play_icon2[id] = false;
        })
      }, false);
    };

  })

  .controller('YuyinCtrl', function ($scope, $ionicSideMenuDelegate, $state,
                                     $rootScope, $ionicModal, TranslateService, ServerData, YuyinLang, $timeout) {
    $scope.index = -1;

    $scope.play_icon = true;
    $scope.play_icon2 = false;
    $scope.lang = {'id': 'YANGJIANG'};
    $scope.Luyinlang = 'zh';
    $scope.sltLang = function (langid) {
      YuyinLang.name = TranslateService.getNamebyId(langid);
      $scope.YuyinLang = YuyinLang;
      localforage.setItem('lang_yuyin', {id: YuyinLang.id, name: YuyinLang.name});

    };

    var audio = document.getElementById('fr').contentWindow.document.getElementById('audio');

    $scope.goBack = function () {
      $rootScope.hideTabs = '';
      $state.go("tab.dash");
    };

    $scope.langChange = function (Luyinlang) {
      voice_lang = Luyinlang;
      console.log(voice_lang)
    };


    $scope.translate = function (message, key) {

      $scope.translate.result = [];

      $scope.play_icon = false;
      $scope.play_icon2 = true;

      $scope.index = key;

      if (message.trim() == '') {
        ServerData.alert('翻译内容不能为空。');
      } else {
        $scope.translate.message = message;
        TranslateService.translateLive($scope.translate.message, YuyinLang.id, function (items) {
          var data = [];
          items.forEach(function (item) {
            if (item != null)data.push(item);
          });
          data = "[" + data + "]";
          $timeout(function () {
            $scope.hasTranslate = true;
            $scope.translate.result = JSON.parse(data);

            var medias = $scope.translate.result;
            $scope.audioLength = medias.length;
            if (medias.length > 0) {

              audio.src = server + medias[0].audio;

              audio.play();

              var j = 0;
              audio.addEventListener('ended', function () {
                $scope.$apply(function () {
                  j++;
                  if (j < $scope.audioLength) {
                    audio.src = server + medias[j].audio;
                    audio.playbackRate = 1;
                    audio.play();
                  }
                });

                $timeout(function () {
                  $scope.play_icon = true;
                }, 1500);
                $scope.play_icon2 = false;

              }, false);
            }

          }, 500);


        });
      }
    };


  })

  .controller('SpeakCtrl', function ($scope, $ionicSideMenuDelegate) {
    /*$scope.toggleLeft = function() {
     $ionicSideMenuDelegate.toggleLeft();
     };*/

    console.log("SpeakCtrl");
  })

  .controller('SettingCtrl', function ($scope, Speed,$timeout, ServerData,$ionicLoading) {
    $scope.speedRate = Speed.value;

    $scope.speedChange = function (rate) {
      $scope.speedRate = rate;
      Speed.value = rate;
      console.log("rate=" + rate + ",speedRate=" + $scope.speedRate);

    };

    $scope.checkVersion = function(){
      $ionicLoading.show();
      $timeout(function () {
        $ionicLoading.hide();
        ServerData.alert("该版本已经是最新版本!")
      }, 600);
    }
  })

  .controller('DownloadCtrl', function ($scope, TranslateService, $ionicSlideBoxDelegate, $ionicPopup, $interval, $state,
                                        $timeout, $ionicActionSheet, $cordovaFileTransfer, ServerData,
                                        $cordovaZip, $cordovaFile, langlist, lang_dialogues, netWorkService) {

    //netWorkService.check(1);

    $scope.langlist = langlist;
    $scope.lang_dialogues = lang_dialogues;
    $scope.slideIndex = 0;
    $scope.lockSlide = function () {
      $ionicSlideBoxDelegate.enableSlide(false);
    }
    // Called each time the slide changes
    $scope.slideChanged = function (index) {
      $scope.slideIndex = index;
      console.log("slide Change");
      if ($scope.slideIndex == 0) {
        console.log("slide 1");
      }

      else if ($scope.slideIndex == 1) {
        console.log("slide 2");
      }

      else if ($scope.slideIndex == 2) {
        console.log("slide 3");
      }

    };

    $scope.activeSlide = function (index) {
      $ionicSlideBoxDelegate.slide(index);

    };

    $scope.downloadStatus = function (items, comparedvalue) {
      var result = {};
      angular.forEach(items, function (value, key) {
        if (value.dwnstatus == comparedvalue) {
          result[key] = value;
        }
      });
      return result;
    };

    $scope.filterDowning = function (items) {
      var result = {};
      angular.forEach(items, function (value, key) {
        if (value.dwnstatus != 'success' && value.dwnstatus != 'download') {
          result[key] = value;
        }
      });
      return result;
    };

    $scope.downloadSize = 0;
    $scope.dialogueSize = 0;

    $scope.download = function (langId) {
      if (langlist[langId].dwnstatus == 'download') {
        this.startDownload(langId);
      } else if (langlist[langId].dwnstatus == 'success') {
        ServerData.showPopup('该语音包已经完成下载');
      } else if (langlist[langId].dwnstatus == 'downing') {
        ServerData.showPopup('该语音包正在下载');
      } else if (langlist[langId].dwnstatus == 'waiting') {
        ServerData.showPopup('该语音包等待下载中');
      } else if (langlist[langId].dwnstatus == 'pause') {
        ServerData.showPopup('该语音包已经暂停下载');
      }
    };

    var url = "http://120.24.158.176:8080/demo/";
    var filePath
    if (window.cordova) {
      filePath = cordova.file.externalApplicationStorageDirectory;
    }
    var fileName = "";
    var targetPath = "";
    var trustHosts = true;
    var options = {};
    $scope.startDownload = function (langId) {
      var uri = encodeURI(url + langId + ".zip");
      fileName = filePath + langId + ".zip";
      //targetPath = filePath + langId + "/";
      targetPath = filePath;
      console.log("uri=" + uri);
      console.log("fileName=" + fileName);
      console.log("targetPath=" + targetPath);

      langlist[langId].dwnstatus = 'downing';
      ServerData.showPopup('你选择的语音包已经加入到下载队列');
      $cordovaFileTransfer.download(uri, fileName, options, trustHosts).then(function (result) {
        //unzipFile(fileName,targetPath);
        unzipFileAndLoadLang(fileName, targetPath);
        langlist[langId].dwnstatus = 'success';
        langlist[langId].progressval = 100;

      }, function (err) {
        console.log(err);
        $interval.cancel(langlist[langId].stopinterval);
        langlist[langId].dwnstatus = 'download';
        ServerData.alert('下载失败！');
        return;
      }, function (progress) {
        $timeout(function () {
          var downloadProgress = (progress.loaded / progress.total) * 100;
          langlist[langId].progressval = Math.floor(downloadProgress);
          if (langlist[langId].progressval > 99) {
            $interval.cancel(langlist[langId].stopinterval);
            langlist[langId].dwnstatus = 'success';
            langlist[langId].stopinterval = true;
            $scope.langlist = langlist;
            $state.go("tab.download");
            return;
          }
        });
      });

    };

    $scope.downloadDialogues = function (langId) {
      if (lang_dialogues[langId].dwnstatus == 'download') {
        this.startDownloadDialogues(langId);
      } else if (lang_dialogues[langId].dwnstatus == 'success') {
        ServerData.showPopup('该语音包已经完成下载');
      } else if (lang_dialogues[langId].dwnstatus == 'downing') {
        ServerData.showPopup('该语音包正在下载');
      } else if (lang_dialogues[langId].dwnstatus == 'waiting') {
        ServerData.showPopup('该语音包等待下载中');
      } else if (lang_dialogues[langId].dwnstatus == 'pause') {
        ServerData.showPopup('该语音包已经暂停下载');
      }
    };

    $scope.startDownloadDialogues = function (langId) {
      var uri = encodeURI(url + "dialogue_" + langId + ".zip");
      fileName = filePath + "dialogue_" + langId + ".zip";

      targetPath = filePath + "dialogues/";
      lang_dialogues[langId].dwnstatus = 'downing';
      ServerData.showPopup('你选择的语音包已经加入到下载队列');
      $cordovaFileTransfer.download(uri, fileName, options, trustHosts).then(function (result) {
        unzipFile(fileName, targetPath);
      }, function (err) {
        $interval.cancel(lang_dialogues[langId].stopinterval);
        lang_dialogues[langId].dwnstatus = 'download';
        ServerData.alert('下载失败！');
        return;
      }, function (progress) {
        $timeout(function () {
          var downloadProgress = (progress.loaded / progress.total) * 100;
          lang_dialogues[langId].progressval = Math.floor(downloadProgress);
          if (lang_dialogues[langId].progressval > 99) {
            $interval.cancel(lang_dialogues[langId].stopinterval);
            lang_dialogues[langId].dwnstatus = 'success';
            lang_dialogues[langId].stopinterval = true;
            $scope.lang_dialogues = lang_dialogues;
            $state.go("tab.download");
            return;
          }
        });
      });


      /*if(lang_dialogues[langId].stopinterval){
       $interval.cancel(lang_dialogues[langId].stopinterval);
       };*/

      //lang_dialogues[langId].stopinterval = $interval(function(){
      /*lang_dialogues[langId].progressval = lang_dialogues[langId].progressval + 1;
       if(lang_dialogues[langId].progressval >=100){
       $interval.cancel(lang_dialogues[langId].stopinterval);
       lang_dialogues[langId].dwnstatus = 'success';
       lang_dialogues[langId].stopinterval = true;
       $scope.lang_dialogues = lang_dialogues;
       $state.go("tab.download");
       return;
       }*/
      /*$cordovaFileTransfer.download(uri,fileName,options,trustHosts).then(function(result){
       /!*$cordovaZip.unzip(fileName,cordova.file.externalApplicationStorageDirectory+"dialogues/"+langId).then(function(resp){
       console.log("unzip success.");
       },function(err){
       console.log("unzip error.");
       },function(progressEvent){
       console.log("unzip progress: "+progressEvent);
       });*!/
       unzipFile(fileName,targetPath);
       },function(err){
       $interval.cancel(lang_dialogues[langId].stopinterval);
       lang_dialogues[langId].dwnstatus = 'download';
       ServerData.alert('下载失败！');
       return;
       },function(progress){
       var downloadProgress = (progress.loaded / progress.total) * 100;
       lang_dialogues[langId].progressval = Math.floor(downloadProgress);
       if(lang_dialogues[langId].progressval > 99){
       $interval.cancel(lang_dialogues[langId].stopinterval);
       lang_dialogues[langId].dwnstatus = 'success';
       lang_dialogues[langId].stopinterval = true;
       $scope.lang_dialogues = lang_dialogues;
       $state.go("tab.download");
       return;
       }
       });*/
      //},100);

    };

    function unzipFile(fileName, directory) {
      $cordovaZip.unzip(fileName, directory)
        .then(function () {
          console.log("Files unzipped");
          deleteFile(filePath, fileName.substr(fileName.lastIndexOf("/") + 1, fileName.length));
        }, function () {
          console.log("Failed to unzip");
        }, function (progressEvent) {
          //console.log(progressEvent);
        });
    };

    function unzipFileAndLoadLang(fileName, directory, langId) {
      $cordovaZip.unzip(fileName, directory)
        .then(function () {
          console.log("Files unzipped");
          TranslateService.load(langId);
          deleteFile(filePath, fileName.substr(fileName.lastIndexOf("/") + 1, fileName.length));
        }, function () {
          console.log("Failed to unzip");
        }, function (progressEvent) {
          //console.log(progressEvent);

        });
    };

    function deleteFile(filePath, fileName) {
      console.log("delete file name = " + fileName);
      console.log("delete file path = " + filePath);
      $cordovaFile.removeFile(filePath, fileName)
        .then(function (success) {
          console.log("File deleted");
        }, function (error) {
          console.log("File failed to delete");
        });
    };

    /*$scope.showPopup = function (value){
     var myPopup = $ionicPopup.show({
     cssClass:'er-popup',
     content: value
     });

     $timeout(function(){
     myPopup.close();
     },1000);
     };*/

    $scope.showTranslateAction = function (langId) {
      var txt = "";
      if (langlist[langId].dwnstatus == 'downing') {
        txt = "<i class=\"icon ion-ios-pause balanced\"></i><b class='balanced'>暂停下载</b>";
      } else if (langlist[langId].dwnstatus == 'success') {
        txt = "<i class=\"icon ion-ios-reload royal\"></i><b class='royal'>下载更新</b>";
      } else {
        txt = "<i class=\"icon ion-ios-download\"></i><b>开始下载</b>";
      }
      ;

      var hideSheet = $ionicActionSheet.show({
        buttons: [
          {text: txt}
        ],
        destructiveText: '<i class=\"icon ion-trash-a assertive\"></i><b>删除</b>',
        cancelText: '<b>取消</b>',
        cancel: function () {
          //add cancel code..
        },
        destructiveButtonClicked: function () {
          $cordovaFile.removeDir(filePath + "translate/", langId).then(function (success) {
            console.log("removed folder :" + langId);
          }, function (error) {
            console.log("error removing folder");
          });
          lang_dialogues[langId].dwnstatus = 'download';
          lang_dialogues[langId].progressval = 0;
          $scope.lang_dialogues = lang_dialogues;
          ServerData.alert('删除成功！');
          return true;
        },
        buttonClicked: function (index) {
          console.log("index=" + index);
          if (langlist[langId].dwnstatus == 'downing') {
            console.log("pause action");
          } else if (langlist[langId].dwnstatus == 'success') {
            console.log("upgrade action");
          } else {
            console.log("download action");
          }
          ;
          return true;
        }
      });
    };

    $scope.showDialogueAction = function (langId) {
      var txt = "";
      if (lang_dialogues[langId].dwnstatus == 'downing') {
        txt = "<i class=\"icon ion-ios-pause balanced\"></i><b class='balanced'>暂停下载</b>";
      } else if (lang_dialogues[langId].dwnstatus == 'success') {
        txt = "<i class=\"icon ion-ios-reload royal\"></i><b class='royal'>下载更新</b>";
      } else {
        txt = "<i class=\"icon ion-ios-download\"></i><b>开始下载</b>";
      }
      ;

      var hideSheet = $ionicActionSheet.show({
        buttons: [
          {text: txt}
        ],
        destructiveText: '<i class=\"icon ion-trash-a assertive\"></i><b>删除</b>',
        cancelText: '<b>取消</b>',
        cancel: function () {
          //add cancel code..
        },
        destructiveButtonClicked: function () {
          console.log("path:" + filePath + "dialogues/");
          console.log("folder name " + langId);
          $cordovaFile.removeDir(filePath + "dialogues", langId).then(function (success) {
            console.log("removed folder :" + langId);
          }, function (error) {
            console.log("error removing folder" + JSON.stringify(error));
          });

          lang_dialogues[langId].dwnstatus = 'download';
          lang_dialogues[langId].progressval = 0;
          $scope.lang_dialogues = lang_dialogues;

          ServerData.alert('删除成功！');

          return true;
        },
        buttonClicked: function (index) {
          console.log("index=" + index);
          if (lang_dialogues[langId].dwnstatus == 'downing') {
            console.log("pause action");
          } else if (lang_dialogues[langId].dwnstatus == 'success') {
            console.log("upgrade action");
          } else {
            console.log("download action");
          }
          ;
          return true;
        }
      });
    };


  })

  .controller('actionsheetCtl', function ($scope, $ionicActionSheet, $timeout, ServerData, $ionicPopup) {
    $scope.show = function () {

      var hideSheet = $ionicActionSheet.show({
        /*buttons: [
         { text: 'Move' }
         ],*/
        destructiveText: '<i class=\"icon ion-trash-a assertive\"></i><b>确定清除历史记录</b>',
        /*titleText: 'Modify your album',*/
        cancelText: '<b>取消</b>',
        cancel: function () {
          // add cancel code..
        },
        destructiveButtonClicked: function () {
          //console.log("delete historys.");
          //return true;
          $scope.storedData = [];
          localforage.setItem('storedDataForage', []);
          ServerData.alert('清除成功！');
          return true;

        },
        buttonClicked: function (index) {
          return true;
        }
      });

      /*$timeout(function() {
       hideSheet();
       }, 2000);*/

    };
  })


  .controller('AdvanceCtrl', function ($scope, $state, advanceService) {

    $scope.msgLists = JSON.parse(localStorage.getItem('msgLists')) || [];

    $scope.goBack = function () {

      $state.go("tab.setting");

    };

    $scope.sendMessage = function () {

      advanceService.send($scope.msg);

      $scope.msgLists.push({'time': new Date().toLocaleString(), 'value': $scope.msg});

      localStorage.setItem('msgLists', JSON.stringify($scope.msgLists));

      $scope.msg = '';

    };


  });

