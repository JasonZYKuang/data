angular.module('starter.nav', ['ngCordova', 'ab-base64'])

  .controller('NavController', function ($scope, $ionicSideMenuDelegate, $ionicLoading, VoiceRecorderService,
                                         FileService, RecognitionService, DeviceStatus, YuyinLang, base64,
                                         NewMedia, $ionicModal, TranslateService, ServerData, netWorkService) {
    $scope.YuyinLang = YuyinLang;
    //netWorkService.check(0);

    $scope.toggleLeft = function () {
      $ionicSideMenuDelegate.toggleLeft();
    };

    console.log("NavController");
    var vm = this;
    vm.history = [];
      /*vm.history.push({
          lang: 'en',
          value: ["Hello","你好"]
      });
      vm.history.push({
          lang: 'zh',
          value: ["普通话你好","普通话你好"]
      });
      vm.history.push({
          lang: 'ct',
          value: ["粤语","你好"]
      });*/

    vm.showHint = false;
    vm.buttonText = "按下 说话";
    vm.canRecord = function () {
      return true;
    };

      console.log(vm.history);
      $scope.showpic = ( vm.history.length == 0 ? true : false );

    vm.startRecord = function () {
      console.log("start record");
      vm.showHint = true;
      vm.buttonText = "松开 结束";
      vm.hintText = "向上滑动 取消识别";

        if (ionic.Platform.isAndroid()) {
            VoiceRecorderService.startRecord(55)
                .then(FileService.readAsArrayBuffer)
                .then(RecognitionService.recognise)
                .then(RecogniseSuccessCallback);
        }else if(ionic.Platform.isIOS()){
            VoiceRecorderService.startRecord4IOS(55)
                .then(FileService.readAsArrayBuffer)
                .then(RecognitionService.recognise)
                .then(RecogniseSuccessCallback);
        }

      /*VoiceRecorderService.startRecord(55)
        .then(FileService.readAsArrayBuffer)
        .then(RecognitionService.recognise)
        .then(RecogniseSuccessCallback);*/
    };
    vm.stopRecord = function () {
      vm.showHint = false;
      vm.buttonText = "按下 说话";
      VoiceRecorderService.stopRecord();
    };

    vm.cancelRecord = function () {
      vm.hintText = vm.buttonText = "松开手指 取消识别";
      VoiceRecorderService.cancelRecord();
    };

    function RecogniseSuccessCallback(resp) {
      console.log("call back:" + resp.err_msg);
      console.log("call back:" + resp.err_no);
      $scope.showpic = false;
      if (voice_lang == 'en') {
        RecognitionService.translate(resp.result[0]).then(function (data) {
          console.log(data.trans_result[0]);
          if (data.trans_result)vm.history.push({
            lang: voice_lang,
            value: [resp.result[0].replace("，", ""),data.trans_result[0].dst.replace(",", "")]
          });
        });

      } else {

        if (resp.err_no == 0) vm.history.push({
          lang: voice_lang,
          value: [resp.result[0].replace("，", ""),resp.result[0].replace("，", "")]
        });

      }

      console.log(resp);

    }


    /*Modal                        ************************************************************************/
    $ionicModal.fromTemplateUrl('templates/lang-yuyin.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function (modal) {
      $scope.modal = modal;

    });

    $scope.openModal = function () {
      $scope.modal.show();
    };

    $scope.sltLang = function () {
      YuyinLang.name = TranslateService.getNamebyId(YuyinLang.id);
      $scope.YuyinLang = YuyinLang;
      localforage.setItem('lang_yuyin', {id: YuyinLang.id, name: YuyinLang.name});
      $scope.modal.hide();
      if (TranslateService.hasLang(YuyinLang.id)) {
        //console.log("sltLang - true");
      } else {
        //console.log("sltLang - false");
        ServerData.alert('请前往设置窗口下载数据包:&nbsp;' + YuyinLang.name);
      }
    };
    $scope.$on('$destroy', function () {
      $scope.modal.remove();
    });


  });
